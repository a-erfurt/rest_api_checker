from pathlib import Path
import json,csv
p=Path(__file__).resolve().parent;d=json.loads((p/'results.json').read_text())
names={'qwen3.6:27b':'Qwen','gemma3:27b':'Gemma','mistral-small3.2:24b':'Mistral'}
def pct(x):return 'nicht verfügbar' if x is None else f'{100*x:.2f}'.replace('.',',')+' %'
def tab(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def read(name):return list(csv.DictReader((p/'tables'/name).open()))
rq1=tab(['Modell','Geplant','Parsergültig','Parserfehler','Gültig, Vektor falsch','Vektor korrekt','K/N','K/V'],[[names[m['model']],m['planned'],m['valid'],m['parser_failure'],m['valid_incorrect'],m['exact_correct'],pct(m['exact_planned']),pct(m['exact_valid'])] for m in d['models']])
binary=tab(['Modell','Binär verfügbar','TP','TN','FP','FN','B/N','Korrekt/B','Precision','Recall*','F1*'],[[names[m['model']],m['binary_available'],m['tp'],m['tn'],m['fp'],m['fn'],pct(m['binary_coverage']),pct(m['binary_conditional']),pct(m['precision']),pct(m['recall_conditional']),pct(m['f1_conditional'])] for m in d['models']])
cat=tab(['Modell','Dimension','Korrekt / geplant','Anwendbar: korrekt / geplant','Falsch anwendbar','Falsch nicht anwendbar','P→F','F→P'],[[names[c['model']],c['category'],f"{c['correct']}/{c['planned']}",f"{c['applicable_correct']}/{c['applicable_planned']}",c['false_applicable'],c['false_not_applicable'],c['category_fp'],c['category_fn']] for c in d['categories']])
strata=[]
for v in ['PPP','PPF','PFN','FNN']:
 gs=[next(g for g in d['selected_subgroups'] if g['grouping']=='reference_vector' and g['group']==v and g['model']==m) for m in names]
 strata.append([v,gs[0]['cases']]+[f"{g['exact_correct']}/{g['planned']} ({pct(g['exact_planned'])})" for g in gs])
strat=tab(['Referenz','Fälle','Qwen','Gemma','Mistral'],strata)
api=tab(['API','Fälle','Qwen','Gemma','Mistral'],[[a,next(g['cases'] for g in d['selected_subgroups'] if g['grouping']=='api' and g['group']==a)]+[f"{g['exact_correct']}/{g['planned']} ({pct(g['exact_planned'])})" for m in names for g in d['selected_subgroups'] if g['grouping']=='api' and g['group']==a and g['model']==m] for a in ['EDX','Resistance']])
stab=tab(['Modell','Vollständige Dreiergruppen','Identische Vektoren / vollständige Gruppen','3/3 korrekt / alle Fälle','Stabil falsch','Variierend','Unvollständig'],[[names[s['model']],f"{s['complete_valid_triples']}/82",f"{s['identical_triples']}/{s['complete_valid_triples']} ({pct(s['identical_given_complete'])})",f"{s['all_three_correct']}/82 ({pct(s['all_three_correct_rate'])})",s['stable_wrong'],s['variable'],s['incomplete']] for s in d['stability']])
rep=tab(['Modell','Seed 101: korrekt / geplant','Seed 202: korrekt / geplant','Seed 303: korrekt / geplant'],[[names[m]]+[f"{r['exact_correct']}/{r['planned']}" for r in d['repetitions'] if r['model']==m] for m in names])
ps=tab(['Vergleich','Paare','Qwen: beide korrekt','Gemma: beide korrekt','Mistral: beide korrekt'],[[grp.split(':')[0]+' '+grp.split(':')[1],next(x['pairs'] for x in d['pair_summary'] if x['group']==grp)]+[f"{x['both_correct']}/{x['paired_repetitions']}" for m in names for x in d['pair_summary'] if x['group']==grp and x['model']==m] for grp in sorted({x['group'] for x in d['pair_summary']})])
report=f'''# Finale deskriptive Evaluation v2 – Experiment 10003

## 1. Datenbasis und Prüfstatus

**Datenbefund.** Die Auswertung verwendet ausschließlich den gelieferten Offline-Analyseexport von Experiment 10003, Dataset 3. Das Eingabe-ZIP hat SHA-256 `7c3951a964ec4a01c9c723e18ae3b52df329cbeb64b80b59df4985c09bebc78c`; die CSV hat SHA-256 `2922e1450a6fefba11902eebc810549a65b468138601fdce4a581a016fe51403`.

Die CSV wurde in der Analyseumgebung mit dem unveränderten mitgelieferten `build_export.py` byteidentisch neu erzeugt. Die gelieferten Prüfsummen, die 738 Einzelzeilen und ihre Verknüpfungen mit Runs, Predictions und finalen Referenzen wurden erneut geprüft. Alle 82 Fälle besitzen im finalen Dataset den Status `HUMAN_CONFIRMED_REFERENCE`. Die früher hochgeladenen PENDING-Vorlagen werden nicht als finale Referenzquelle verwendet. Die 82 dort enthaltenen Body-Texte stimmen jedoch nach separatem SHA-256-Abgleich mit den im finalen Dataset gebundenen Response-Bodys überein; nur diese Textdarstellung wird ergänzend für die qualitative Analyse verwendet.

Die lokale Originalprüfung dokumentiert die Prüfung von 6.238 Archivdateien. Diese vollständigen Datei-Inhalte sind nicht sämtlich im Analysepaket enthalten. Der vorliegende Schritt prüft das gelieferte Paket und den Snapshot, nicht erneut die lokale SQL-Datenbank oder 6.238 Original-Payloads. Das mitgelieferte zusätzliche Verifikationsskript erreicht hier seine abschließenden Kontrollen von `/Users/aerfurt/...` nicht; diese Pfade gehören zum ursprünglichen Rechner. Das ist kein Export- oder Datenfehler. Die portable CSV-Reproduktion und die eigene Prüfung der Snapshot-Zuordnungen waren erfolgreich. Vollständige Rohbytes der OpenAPI-Dokumente fehlen ebenfalls im Paket; es wurde keine neue Referenzvalidierung durchgeführt.

Es liegen 738 logische Runs mit 738 Versuchen und ohne Retries vor: 734 parsergültige Ausgaben, vier Parserfehler und keine technischen Fehlausgänge. Das entspricht 82 Fällen × drei Konfigurationen × drei Wiederholungen. Pro Konfiguration gibt es 246 geplante Bewertungen. Verglichen werden `qwen3.6:27b`, `gemma3:27b` und `mistral-small3.2:24b` mit P2, `format_json`, 512 maximalen Ausgabetokens und den Seeds 101, 202 und 303.

## 2. Auswertungsregeln und Grenzen der Statistik

**Beibehaltene Auswertungsdefinitionen.** Das primäre Maß für RQ1 ist die vollständige Übereinstimmung des C1/C2/C3-Vektors mit der finalen Referenz. Korrekte Vektoren werden sowohl über alle geplanten Runs (K/N) als auch über parsergültige Ausgaben (K/V) berichtet. Fehlende Predictions bleiben im geplanten Nenner, erhalten aber keine nachträglich konstruierten Zustände.

Nur die kohärenten Vektoren PPP, PPF, PFN und FNN erlauben die binäre Ableitung CONSISTENT/INCONSISTENT. INCONSISTENT ist die positive Klasse. Ein parsergültiger inkohärenter Vektor bleibt in Kategorie- und Vektorauswertungen enthalten, nicht aber in der binären Konfusionsmatrix. Precision, Recall und F1 sind daher bedingt auf die Verfügbarkeit binärer Urteile; die binäre Abdeckung wird mit angegeben. Ein technischer oder Formatfehler wird nicht zu einem semantischen False Negative umgedeutet.

Für RQ2 werden referenzseitige Anwendbarkeit, P/F-Verwechslungen und Anwendbarkeitsfehler unterschieden. Für RQ3 werden identische Vektoren nur unter vollständigen parsergültigen Dreiergruppen bestimmt. Das strengere Kriterium „in allen drei Wiederholungen korrekt“ verwendet alle 82 Fälle als Nenner. Es gibt keine Mehrheitsentscheidung als neuen Detector.

**Deskriptive Einordnung.** Die 82 Fälle bilden 30 dokumentierte Abhängigkeitsfamilien, 51 exakte Modellkontexte und 19 Response-Mustergruppen. Auch 30 Familien oder 51 Kontexte sind nicht als statistisch unabhängige Stichprobe nachgewiesen; `independent_scientific_ancestry` lautet durchgehend UNESTABLISHED. Fallwiederholungen, ähnliche Konstruktionen und identische Kontexte werden nicht als unabhängige Stichproben behandelt. Deshalb werden keine p-Werte, Konfidenzintervalle unter einer Unabhängigkeitsannahme oder Populationsschätzungen ausgewiesen. Die Auswertung verändert weder den Datensatz noch die Referenzen. Detaildarstellung der Paaranalyse und Auswahl qualitativer Beispiele sind ergänzende Analysen nach Vorliegen der Ergebnisse, keine nachträglich behauptete Präregistrierung.

## 3. RQ1 – Genauigkeit und Ausgabeabdeckung

{rq1}

Quelle: `tables/rq1_models.csv`; ein technischer Fehlausgang wurde bei keinem Modell beobachtet.

Qwen liefert bei allen 246 geplanten Bewertungen einen referenzgleichen Vektor. Gemma erreicht 168/246 = 68,29 %. Mistral erreicht 164/246 = 66,67 % über geplante und 164/242 = 67,77 % über gültige Ausgaben. Gemma und Mistral haben jeweils 78 gültige, aber falsche Vektoren; bei Mistral kommen vier fehlende Predictions durch Parserfehler hinzu. Die Differenz von vier korrekten Vektoren zwischen Gemma und Mistral ist ein deskriptiver Befund, kein Signifikanznachweis und kein kausaler Effekt des Ausgabeformats.

Die 100 % von Qwen betreffen die drei Zustandsurteile in diesem festgelegten Datensatz. Sie sind weder ein Nachweis allgemeiner Fehlerfreiheit noch ein Ergebnis zur vollständigen Begründungskorrektheit. Abschnitt 7 zeigt eine sachlich falsche Beschreibung eines Body-Werts trotz richtigem Vektor.

### Binäre Ergebnisse

{binary}

*Recall und F1 beziehen sich auf die Teilmenge verfügbarer binärer Urteile. Quelle: `tables/rq1_models.csv`.*

Bei Mistral sind 42 gültige Ausgaben `NOT_APPLICABLE / NOT_APPLICABLE / NOT_APPLICABLE` (NNN). Diese inkohärenten Vektoren ergeben nach der beibehaltenen Auswertungsregel kein binäres Urteil. Zusammen mit den vier Parserfehlern bleiben 46/246 geplante Runs ohne binäre Entscheidung; die Abdeckung beträgt 81,30 %. Sämtliche 46 betreffen referenzseitig inkonsistente Fälle. Damit umfasst Mistrals bedingter Recall nur 113 der 159 geplanten inkonsistenten Bewertungen: 84/113 = 74,34 %. Gemmas Recall umfasst dagegen alle 159 und beträgt 87/159 = 54,72 %.

Der höhere bedingte F1 von Mistral (82,35 % gegenüber 69,05 %) ist deshalb keine vollständige Modellrangfolge. Als zusätzliche transparente Zählung liefert Mistral in 84/159 = 52,83 % aller vorgesehenen inkonsistenten Bewertungen ein verwendbares richtiges binäres Urteil; Gemma in 87/159 = 54,72 %. Die übrigen Mistral-Ausgaben werden dabei nicht zu zusätzlichen False Negatives umklassifiziert. Die primäre Vektorkorrektheit erhält unverändert den gemeinsamen Nenner 246.

Im vorliegenden Ergebnisbestand sind die Zahlen richtiger binärer Urteile und richtiger vollständiger Vektoren zufällig gleich. Das ist ein empirischer Befund dieses Laufs, keine Äquivalenz der Maße.

## 4. RQ2 – Dimensionen, Referenzgruppen und Fehlertypen

### C1, C2 und C3

{cat}

Quelle: `tables/rq2_categories.csv`. P→F und F→P zählen Zustandsverwechslungen; falsche Anwendbarkeit und falsche Nichtanwendbarkeit stehen separat. C1 ist in 82, C2 in 68 und C3 in 39 Fällen anwendbar; nach drei Wiederholungen ergeben sich die Nenner 246, 204 und 117. Die All-State-Sicht zählt jede Kategorie über 246 geplante Bewertungen einschließlich korrekter NOT_APPLICABLE-Zustände. Mistrals vier Parserfehler bleiben ohne Kategorieurteil.

Gemma hat 42 C1-Verwechslungen von FAIL zu PASS. In denselben 42 Runs werden C2 und C3 fälschlich als anwendbar behandelt. Das sind 42 Runs mit Anwendbarkeitsfehlern und insgesamt 84 betroffene Kategorieentscheidungen, nicht 84 unabhängige Fehlerruns. Unter den tatsächlich anwendbaren C3-Prüfungen kommen 30 übersehene Schemaabweichungen und sechs fälschliche Beanstandungen hinzu.

Mistral ersetzt in den 42 FNN-Referenzbewertungen C1=FAIL durch NOT_APPLICABLE; C2 und C3 bleiben korrekt nicht anwendbar. Diese 42 Fälle sind C1-Anwendbarkeitsfehler und erzeugen die NNN-Vektoren. Bei anwendbarem C3 treten 29 FAIL→PASS- und sieben PASS→FAIL-Verwechslungen auf. Die 206/246 richtigen C3-Zustände enthalten 125 richtige NOT_APPLICABLE-Werte. Unter tatsächlich anwendbaren C3-Prüfungen bleiben nur 81/117 = 69,23 % korrekt. Gemma erreicht dort ebenfalls 81/117, aber mit anderer Fehlerverteilung.

C2 ist bei allen drei Modellen auf den verfügbaren, referenzseitig anwendbaren Prüfungen korrekt. Mistral hat dort 200/200 richtige verfügbare Urteile; vier weitere geplante C2-Bewertungen haben wegen Parserfehlern kein Urteil. Die uneingeschränkte Behauptung „alle C2-Bewertungen richtig“ wäre deshalb unpräzise.

### Referenzvektoren

{strat}

Quelle: `tables/rq2_subgroups.csv`, Gruppierung `reference_vector`. Die Nenner enthalten jeweils alle Wiederholungen der betreffenden Fälle.

Die Ergebnisprofile unterscheiden sich deutlich. Qwen bewertet alle vertretenen Gruppen richtig. Gemma erkennt in diesem Datensatz keine der 30 wiederholten PPF- und keine der 42 FNN-Referenzbewertungen vollständig richtig. Mistral erreicht bei PPF einen richtigen Vektor und bei FNN keinen. PFN wird von allen drei Modellen in allen verfügbaren gültigen Ausgaben korrekt beurteilt; Mistral verliert vier Bewertungen an das Ausgabeformat.

### API-bezogene Ergebnisse

{api}

Quelle: `tables/rq2_subgroups.csv`, Gruppierung `api`.

EDX enthält 14 PPP-, 10 PPF-, 14 PFN- und 14 FNN-Fälle. Resistance enthält 15 PPP- und 15 PFN-Fälle, keine PPF- oder FNN-Fälle. Die zehn PPF-Fälle von EDX betreffen laut finaler Referenzdokumentation unzulässige großgeschriebene Properties; sie sind nicht zehn unterschiedliche Schemafehlermechanismen. Resistance umfasst konforme 200-Responses unter einem leeren Schema und das konforme 422-Kontrollpaar.

**Interpretation.** Die höheren Werte auf Resistance dürfen nicht als isolierte Wirkung der API-Zugehörigkeit interpretiert werden. API, Referenzklasse und konkrete Vertrags-/Konstruktionsbedingungen sind miteinander verbunden. Ebenso ist ein Unterschied zwischen C1, C2 und C3 kein Beleg für eine allgemeine Schwierigkeitsrangfolge der Dimensionen. Für Resistance wurde hier keine Erkennungsleistung bei C1- oder C3-Verletzungen gemessen.

### Konkrete False Positives und False Negatives

Gemmas 72 binäre False Negatives bestehen aus 30 PPF→PPP- und 42 FNN→PPP-Fehlentscheidungen. Seine sechs False Positives betreffen `V2-RES-027` und `V2-RES-028` mit je drei Wiederholungen: das konforme 422-Kontrollpaar. Diese beiden Fälle teilen einen exakten Modellkontext.

Mistrals 29 binäre False Negatives liegen in den PPF-Fällen von EDX. Seine sieben False Positives entstehen sechs Mal bei `V2-RES-019`/`021` und einmal bei `V2-EDX-016`, Seed 303. Die beiden Resistance-Fälle teilen ebenfalls einen exakten Modellkontext. Die 42 NNN-Ausgaben und vier Parserfehler gehören nicht zusätzlich zur binären FN-Zahl.

Das vollständige Run-Inventar einschließlich aller gespeicherten Begründungen der fehlerhaften oder fehlgeschlagenen Bewertungen steht in `tables/error_inventory.csv`. Kategorie-Konfusionszählungen stehen in `tables/rq2_category_confusion.csv`, die vollständigen Vektormuster in `tables/vector_confusion.csv`.

## 5. Ergänzende Original-/Varianten-Vergleiche

Die im Dataset gespeicherten Paarverknüpfungen enthalten 39 Vergleiche mit beiden Partnern im Main-Datensatz. Weitere 21 verweisen auf ausgeschlossene Originale, die nur als Herkunftsnachweis dienen. Diese Originale erhalten keine nachträglich ergänzten Main-Predictions. Die Paarbewertung vergleicht jeweils dieselbe Konfiguration und dieselbe Wiederholung. „Beide korrekt“ verlangt die richtigen vollständigen Referenzvektoren beider Partner, nicht bloß irgendeinen Wechsel der Modellantwort.

{ps}

Quelle: `tables/rq2_pair_summary.csv`. Nenner sind Paar-Wiederholungen; acht Paare ergeben beispielsweise 24 Vergleiche. Die Wiederholungen und Paare sind keine unabhängigen Beobachtungen.

Qwen beurteilt beide Partner in allen 117 Paar-Wiederholungen je Modell richtig. Gemma erreicht 39/117, Mistral 38/117. Unter Mistral liegen für 113/117 Paar-Wiederholungen zwei gültige Ausgaben vor. Die in beiden Dimensionen problematischen PPF→FNN-Übergänge von EDX würden bei einer rein binären Paaranalyse verborgen bleiben: Beide Referenzen lauten INCONSISTENT, aber die korrekte Kategoriezuordnung ändert sich.

Der Name `c2_regressive` ist keine automatische Zielklasse. Beim Resistance-422-Kontrollpaar bleiben Header, Struktur und Referenzvektor unverändert PPP; es wird getrennt als REQUEST_VALIDATION_CONTROL ausgewertet. Ebenso ist die Formatierungskontrolle ein Vergleich mit unveränderter Referenz, kein zusätzlicher Fehlernachweis. Dass Gemma oder Mistral bei einer solchen Kontrolle dieselbe falsche Antwort wiederholen, belegt nur Gleichheit, nicht richtige Vertragsprüfung.

## 6. RQ3 – Wiederholungsstabilität

{stab}

Quelle: `tables/rq3_stability.csv` und `tables/rq3_case_model_triples.csv`.

Qwen und Gemma geben bei sämtlichen 82 Fällen über die drei Seeds identische Vektoren aus. Bei Qwen sind alle richtig; Gemma wiederholt bei 26 Fällen durchgehend einen falschen Vektor. Gemma ist hier damit ebenso entscheidungsstabil wie Qwen, aber nicht ebenso korrekt.

Mistral hat 80 vollständige gültige Dreiergruppen. Davon sind 78 identisch (97,50 %), einschließlich 25 stabil falscher Gruppen. 53/82 Fälle sind in allen drei Wiederholungen richtig. Die zwei unvollständigen Gruppen betreffen `V2-RES-020` und `V2-RES-022`: jeweils Parserfehler bei 101 und 303, PFN bei 202. Wiederholte Formatfehler werden nicht als semantische Stabilität gewertet. Die 14 stabilen NNN-Gruppen bleiben dagegen in der Vektorstabilität enthalten, weil diese Ausgaben parsergültig sind; für eine binäre Dreiergruppe sind sie nicht verwendbar.

Die einzigen zwei vollständigen Gruppen mit unterschiedlichen Vektoren sind:

| Fall | Referenz | Seed 101 | Seed 202 | Seed 303 |
| --- | --- | --- | --- | --- |
| V2-EDX-015 | PPF | PPP | PPF | PPP |
| V2-EDX-016 | PPP | PPP | PPP | PPF |

Beide gehören zur gleichen EDX-Familie und bilden Original und konforme Variante. Sie sind daher keine zwei unabhängigen Belege für einen Variationseffekt. Drei verschiedene Vektoren innerhalb einer vollständigen Dreiergruppe treten nicht auf.

{rep}

Gleiche Gesamtergebnisse pro Seed reichen allein nicht als Stabilitätsnachweis; maßgeblich ist der zusätzliche Vergleich der Einzelvektoren. Umgekehrt belegen drei feste Seeds keine künftige Deterministik und keine allgemeine Robustheit bei anderen Laufzeitumgebungen, Prompts oder Verträgen.

## 7. Qualitative Analyse ausgewählter Modellbegründungen

Diese Auswahl wurde nach Sichtung der Ergebnisdaten getroffen. Sie erläutert Fehlertypen, bildet aber keine quantitative oder repräsentative Bewertung aller Begründungen. Die wörtlichen gespeicherten Texte, Referenzgründe und hashgeprüften Response-Bodys stehen in `qualitative_examples.json`. Die vollständigen Rohverträge fehlen im gelieferten ZIP; Aussagen über Vertragsregeln beziehen sich daher auf die finale dokumentierte Referenzprüfung. Aus ausgegebenen Begründungen werden keine verborgenen Denkprozesse abgeleitet.

### 7.1 Gemma: falscher Statusabgleich

`V2-EDX-003`, Run 10454, Seed 101: Die Referenz ist FNN. Gemma liefert PPP und begründet C1 mit „Status 201 matches documented response 200.“ Der ausgegebene Text setzt unterschiedliche konkrete Statuscodes gleich. Die gespeicherte Referenz dokumentiert dagegen fehlende Abdeckung für 201. Nach dieser falschen Statusentscheidung bewertet Gemma auch die beiden nachgelagerten Dimensionen, die referenzseitig nicht anwendbar sind. Das Beispiel veranschaulicht das gemeinsame Auftreten eines Statusfehlers und nachgelagerter Anwendbarkeitsfehler. Es belegt nicht, welche interne Regel Gemma verwendet hat.

### 7.2 Mistral: fehlende Statusabdeckung erkannt, falscher Zustand ausgegeben

Derselbe Fall, Run 10457, Seed 101: Mistral gibt für alle drei Dimensionen NOT_APPLICABLE aus und nennt jeweils „no matching status entry“. Die Begründung benennt somit den im Referenzverfahren entscheidenden Umstand. Nach P2 müsste C1 aber FAIL erhalten; nur C2 und C3 sind nicht anwendbar. Die Ausgabe ist parsergültig, verletzt die operationale Zustandsregel und erlaubt kein binäres Gesamturteil. Dieses Verhalten liegt bei allen 42 FNN-Bewertungen vor.

### 7.3 Übersehene EDX-Schemaabweichung

`V2-EDX-001`, Gemma Run 10436 und Mistral Run 10439, Seed 101: Beide geben PPP aus und behaupten Schemakonformität. Der gebundene Body enthält `Code`, `Message`, `Warning`, `Mode` und `Data`; die finale Referenz begründet PPF mit unzulässigen zusätzlichen Properties gegenüber dem kleingeschriebenen Schema. Die allgemeinen Begründungen der beiden Modelle benennen diesen Konflikt nicht. Bei Mistrals einzigem richtigen PPF-Urteil (`V2-EDX-015`, Run 10566) lautet die Erklärung lediglich „body is valid JSON but violates the schema“; der richtige Zustandsvektor belegt hier noch keine genaue Lokalisierung der Verletzung.

### 7.4 Mistral: unzulässige Beanstandung unter dem leeren Schema

`V2-RES-019`, Run 11069, Seed 101: Der Body enthält `Code:300`, eine fachliche Fehlermeldung und `Mode:null`. Die finale Referenz ist PPP unter dem leeren 200-Schema. Mistral gibt PPF aus. Seine Begründung lautet: „Empty schema permits any valid JSON instance, but the observed body is not an instance of the empty schema“. Sie nennt keine im Vertrag dokumentierte Einschränkung, die diesen gültigen JSON-Body ausschließt. Der Body-Code 300 ist kein HTTP-Status und keine zusätzliche C3-Schemaregel. Bei `V2-RES-021` und über alle drei Wiederholungen tritt dasselbe Vektorergebnis auf; beide Fälle teilen den exakten Kontext.

### 7.5 Gemma: False Positive bei der 422-Kontrolle

`V2-RES-027`, Run 11138, Seed 101: Gemma liefert PPF mit „Body does not conform to HTTPValidationError schema.“ Die finale Referenz lautet PPP. Die Erklärung benennt weder eine verletzte Vertragsstelle noch ein fehlerhaftes Feld. Aus dieser allgemeinen Aussage lässt sich die Ursache der Fehlentscheidung nicht weiter bestimmen. Beide Fälle der 422-Kontrolle werden in allen drei Wiederholungen falsch zurückgewiesen.

### 7.6 Qwen: richtiger Vektor, sachlich falsche Body-Beschreibung

`V2-EDX-016`, Run 10568, Seed 101: Qwen liefert den richtigen Vektor PPP, beschreibt aber `message`, `warning` und `mode` gemeinsam als Zeichenketten. Im nach SHA-256 identischen Body steht `message:null`. Das ist eine überprüfbare Ungenauigkeit der Begründung, obwohl das C3-Urteil stimmt. In `V2-EDX-001`, Run 10433, spricht Qwen außerdem von „required camelCase properties“, obwohl die finale Referenz diese Properties ausdrücklich als optional beschreibt. Dort nennt die Begründung zusätzlich den richtigen Verstoß durch verbotene weitere Properties. Die gemessenen 100 % Vektorkorrektheit dürfen deshalb nicht als 100 % Begründungskorrektheit dargestellt werden.

### 7.7 Die vier Parserfehler

Runs 11078, 11080, 11096 und 11098 enthalten jeweils `c3` innerhalb von `c2`, statt als eigenes Top-Level-Feld. Der Parser meldet CATEGORY_FIELDS; alle vier Providerantworten endeten mit `done_reason=stop`. Die erhaltenen Inhalte können als Formatfehler beschrieben werden, bleiben aber ohne gültige Prediction. Keine Extraktion oder Umformung wird nachträglich als korrektes Main-Ergebnis gezählt.

## 8. Formulierungsvorschläge für die Antworten auf RQ1–RQ3

### RQ1

Unter der festgelegten Konfiguration erreichte Qwen für alle 246 geplanten Bewertungen einen vollständig referenzgleichen C1/C2/C3-Vektor. Gemma erreichte 168/246 (68,29 %) und Mistral 164/246 (66,67 %). Bei Qwen und Gemma waren sämtliche Ausgaben parsergültig, bei Mistral 242/246. Weitere 42 Mistral-Ausgaben waren parsergültig, aber inkohärent und deshalb nicht binär auswertbar. Die Ergebnisse beschreiben die ausgewählten Response-Fälle und Konfigurationen, nicht eine allgemeine Zuverlässigkeit der Modellfamilien oder die Korrektheit aller ausgegebenen Begründungen.

### RQ2

Die Fehler verteilen sich unterschiedlich auf Dimensionen und Fallgruppen. Gemma übersah alle untersuchten PPF- und FNN-Referenzbewertungen und bewertete nach falschem Statusabgleich auch nicht anwendbare Dimensionen. Mistral gab bei allen FNN-Bewertungen fälschlich NOT_APPLICABLE für C1 aus und erkannte nur eine der 30 PPF-Bewertungen vollständig richtig. PFN wurde in allen verfügbaren gültigen Ausgaben richtig bewertet. Fälschliche Schemaabweichungen betrafen bei Gemma insbesondere die konforme Resistance-422-Kontrolle und bei Mistral zwei Resistance-Fälle unter einem leeren Schema. Da PPF und FNN ausschließlich bei EDX vertreten sind und ähnliche Response-Kontexte mehrfach auftreten, lassen sich daraus keine isolierten API-Effekte oder allgemeine Schwierigkeitsunterschiede der Dimensionen ableiten.

### RQ3

Qwen und Gemma lieferten für alle 82 Fälle identische Entscheidungsvektoren über die drei Wiederholungen. Bei Qwen waren diese durchgehend richtig, bei Gemma in 26 Fällen durchgehend falsch. Mistral lieferte für 80 Fälle drei parsergültige Ausgaben; 78 dieser Gruppen enthielten identische Vektoren. Insgesamt wurden 53/82 Fälle von Mistral in jeder Wiederholung richtig bewertet. Die beiden variierenden vollständigen Gruppen gehören zur selben EDX-Familie; zwei weitere Gruppen sind durch Parserfehler unvollständig. Hohe Wiederholungsübereinstimmung ist daher von Korrektheit zu unterscheiden und belegt keine allgemeine Deterministik.

## 9. Konsequenzen für die Thesis

Die RQs bleiben unverändert. Kapitel 5 kann jetzt auf Basis dieser Auswertung geschrieben werden. Haupttabellen sollten Ausgabe-/Vektorergebnisse, Dimensionen mit Anwendbarkeitsnennern, Referenzgruppen und Wiederholungsstabilität zeigen. Binäre Kennzahlen benötigen unmittelbar ihre Abdeckung. Die Paaranalyse und wenige qualitative Originalausgaben ergänzen die Ergebnisse; sie dürfen nicht die unveränderten primären Maße ersetzen.

Kapitel 3 muss die tatsächlichen Nenner und den Unterschied zwischen Parsergültigkeit, Vektorkohärenz und inhaltlicher Korrektheit abbilden. Die Erstellung dieses Offline-Analysebestands ist von einem in der Datenbank gespeicherten Evaluationsbericht zu unterscheiden: Der ursprüngliche CLI-Export konnte diesen nicht erzeugen; ausgewertet wurde ein hashgebundener Snapshot mit eigenständigem Offline-Auswertungscode. Kapitel 4 darf daher keine nicht durchgeführte Main-v2-Berichtsarchivierung in SQL behaupten. V1-Formatprobleme und frühere explorative Nachbearbeitungen sind keine v2-Hauptergebnisse.

## 10. Ergebnisartefakte

`evaluate_rqs.py` erzeugt alle maschinenlesbaren Tabellen und `results.json` aus dem unveränderten Eingabe-ZIP. `analysis_verification.json` dokumentiert die hier durchgeführten Prüfungen und ihre Grenzen. `parser_failures.json` erhält die vier Originalfehlerbelege. `all_stored_predictions.json` enthält die unveränderten gespeicherten 734 Predictions einschließlich Begründungen. `qualitative_examples.json` verknüpft ausgewählte Runs mit den endgültigen Referenzangaben. `tables/error_inventory.csv` enthält alle 160 nicht vollständig richtigen geplanten Bewertungen (156 gültige falsche Vektoren und vier Parserfehler), ohne Fehlerklassen umzudeuten.
'''
(p/'EVALUATION_V2_RQ1_RQ3.md').write_text(report,encoding='utf-8')
print('Report words',len(report.split()))
