# Experiment 10003 – deskriptive Auswertung

## Reproduktion

Python 3.10 oder neuer, nur Standardbibliothek. Das unveränderte Eingabe-ZIP stammt aus dem gelieferten Offline-Export.

```bash
python3 evaluate_rqs.py --input-zip /path/experiment_10003_offline_analysis.zip --output /path/NEW_RESULTS --review-details /path/case_review_details.md
```

`--review-details` ist optional und wird ausschließlich für hashgleiche Response-Body-Texte verwendet, niemals zur Übernahme alter Referenzvorschläge. Ohne diese Datei bleiben sämtliche quantitativen Ergebnisse identisch.

Alle CSV-Dateien unter `tables/` und `results.json` werden deterministisch aus den Quellen erzeugt. `qualitative_examples.json` enthält eine nach Ergebnissichtung ausgewählte, nicht repräsentative Beispielsammlung. Ein fehlendes binäres Urteil ist keine False-Negative-Klassifikation. Die Auswertung verändert keine Originaldaten und kontaktiert keine Dienste.

Die finalen Referenzen werden aus dem verifizierten Snapshot gelesen und mit `sources/dataset.json` abgeglichen. Im Paket fehlen vollständige OpenAPI-Rohdokumente; es erfolgt keine erneute Referenzvalidierung. Die Dateien aus der ersten manuellen Review dienen nur nach Hashabgleich zur Anzeige der Response-Bytes.

Die deutschsprachige Ergebnisdarstellung und die Excel-Arbeitsmappe sind zusätzliche Darstellungen dieser Auswertung; `evaluate_rqs.py` erzeugt die maschinenlesbaren Ergebnistabellen.
