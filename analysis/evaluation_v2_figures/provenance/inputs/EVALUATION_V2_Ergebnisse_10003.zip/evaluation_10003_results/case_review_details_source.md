# Einzelnachweise für die manuelle Review

Alle 82 Zeilen sind PENDING. [Kompakte Familienübersicht](manual_review.md). Die sichtbaren Vorschläge ersetzen keine menschliche Prüfung.

### V2-EDX-001

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `b37974f3-3cb2-46c7-b804-5f5d678b5431`; Quellbeobachtung `JCR-EDX-001-original`. [Provenienz und Header](provenance/V2-EDX-001.json) · [Request](evidence/03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Body | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Metadatenidentität | 1ba98afc2d3959c67269614878a633c6d4a813ded0b8fb27c660cb8030b962d8 |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | e049a9a22e6eca371baf3a137d66904de8dc307f79117f5385af912494b0a919 |

### V2-EDX-002

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `3152eb0e-0be5-4fca-869a-d6aa213eefe8`; Quellbeobachtung `JCR-EDX-001-conforming`. [Provenienz und Header](provenance/V2-EDX-002.json) · [Request](evidence/03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"Raw","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Body | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Metadatenidentität | d7f4a6c41271fd995edc0b475bdc4ca128647d09bfd1b84b3c722344d4fad229 |
| Response | 64469cffa1349926de46a729fa185f855c03e1015350262c3a2090e165f7c9f1 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 2e4c97ebf7ced48c8b68214ddb8e1fd24cac12edac0beac63d35ffcbd4179eeb |

### V2-EDX-003

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `e1a9c8cc-4ab2-4af5-9fa7-41cd775db0ea`; Quellbeobachtung `JCR-EDX-001-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-003.json) · [Request](evidence/03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Body | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Metadatenidentität | 3b71938a28bdfafa4b4301565c052904fc2c638b4e503df7aa378488cda3cfcc |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d14cb2e0e9e680a0d0833d430d81783235f38454274936fb8b9735aad4ae04ae |

### V2-EDX-004

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `4fa1135e-986e-4260-9aee-e9d8e011ba2f`; Quellbeobachtung `JCR-EDX-001-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-004.json) · [Request](evidence/03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Body | 03078a53e72182859c0155821f72974fcb330fd8a39b3951632c35282d96fcaa |
| Request-Metadatenidentität | 76f3cb18cfaa00c1ec1cc9cfe71a16aa5ccff4920b1b790937b17dec0e569193 |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 1502c38cd1093dd40428d9122294bc3768d7f556f9f0bf508d95a3d4846932df |

### V2-EDX-005

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `77b3d42f-d93d-404c-8c14-fa98e100e0af`; Quellbeobachtung `JCR-EDX-004-conforming`. [Provenienz und Header](provenance/V2-EDX-005.json) · [Request](evidence/17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Body | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Metadatenidentität | 124eba6b532e6cef176feeb8b1ef76c4271f3a896cd692bfe2bde453310a001d |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-006

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `2e8a3844-1e4e-41eb-9f01-2e32c549842d`; Quellbeobachtung `JCR-EDX-004-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-006.json) · [Request](evidence/17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Body | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Metadatenidentität | ac786c868e5847a9f8ae61c7aea6a4d2553c34bf2bbaff909607dde5e04573d2 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-007

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `a5a4d447-5746-403e-8b21-590f7525dce5`; Quellbeobachtung `JCR-EDX-004-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-007.json) · [Request](evidence/17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Body | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Metadatenidentität | bcacceef4c813ffb66acb948585799c7ebcdc1fcfd6690cee77e157bf92ee0f9 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-008

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `9eccb10e-27ca-43ea-8aa6-b35273532cc6`; Quellbeobachtung `JCR-EDX-004-contract_state_control`. [Provenienz und Header](provenance/V2-EDX-008.json) · [Request](evidence/17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{
  "Code": 0,
  "Message": null,
  "Warning": null,
  "Mode": "CSV",
  "Data": null
}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Body | 17677400c52325b3bf6118bce2586daad53fb68c86830a555e47cfebb803968c |
| Request-Metadatenidentität | 5d2d262708869f8f9b0a6f2dbbdd30558a735250331060d192d026dcda50c1ad |
| Response | a9291f7cb045a5c73d93970f249d98b2ae582afebf502dae5387529714d5b9a2 (86 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | fada3e76d48849c179fbcf7a7a517d11960032abea389a480641f9d000bc4f46 |

### V2-EDX-009

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `d7e6742c-a541-4a48-bb02-fc1c1be6163e`; Quellbeobachtung `JCR-EDX-005-conforming`. [Provenienz und Header](provenance/V2-EDX-009.json) · [Request](evidence/17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Body | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Metadatenidentität | c49592e3fbb0ccd9c7969d3b03736870782488e8e133ee656f17a288745359e6 |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-010

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `de2ea5a0-171e-4a0b-a0d3-98fb98b04de4`; Quellbeobachtung `JCR-EDX-005-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-010.json) · [Request](evidence/17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Body | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Metadatenidentität | c13dc9ea9b0a76f1fae4fcbcd51fef691c361fcca8e8f11f19a1a7b41775685d |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-011

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `5ffe2cc3-4352-4bca-a39c-3a077a4dda44`; Quellbeobachtung `JCR-EDX-005-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-011.json) · [Request](evidence/17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Body | 17f6b1a4f1bca4281f2af1a67933db62a2924325fccdd3533bb8cbaac2718861 |
| Request-Metadatenidentität | 3e99c9a79929a6bbae763fbb467382a9760e5246363b533a06f65c25591e231c |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-012

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `16800a7c-a990-45da-a9d2-79a11c4396c5`; Quellbeobachtung `JCR-EDX-019-conforming`. [Provenienz und Header](provenance/V2-EDX-012.json) · [Request](evidence/3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Body | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Metadatenidentität | 17a7e45eaeb8e3f097a530430a70e42008dc0325613262e661d49796ae391289 |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-013

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `621547aa-159a-4ef2-86c1-bb2517d25b48`; Quellbeobachtung `JCR-EDX-019-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-013.json) · [Request](evidence/3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Body | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Metadatenidentität | 8436f1abb2ff7a817cc6952edf1a18cf682cb82751f9f339ce156a0bac39d1b0 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-014

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `7d1f7536-048d-48e8-986a-35d5e24a0f11`; Quellbeobachtung `JCR-EDX-019-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-014.json) · [Request](evidence/3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Body | 3fa8df203536bd128209b5433554e57cbe8447299b73a8bfbbbc6d7829369e38 |
| Request-Metadatenidentität | 755fc453174ee30c55c08295b6350697199618242c887e1ab0e0943f38a86525 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-015

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `0670edc2-1b52-4133-ae90-e2ec655f3d1f`; Quellbeobachtung `JCR-EDX-021-original`. [Provenienz und Header](provenance/V2-EDX-015.json) · [Request](evidence/4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 9: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Body | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Metadatenidentität | 98f7b4acb3666c0f174bfbd8d55258a1e0af0d38beed72de2ae2181e36e7fc79 |
| Response | b8a1db91985483ca56949d9c74e92fc1722da23662cc2c70f6d76d2234e8816e (122 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 42bad05d9902cc240151300d80386d70b97f59350a9dea4f9590056932a4b912 |

### V2-EDX-016

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `03755ee6-5e82-4b4d-a3fd-869b76b6d948`; Quellbeobachtung `JCR-EDX-021-conforming`. [Provenienz und Header](provenance/V2-EDX-016.json) · [Request](evidence/4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":"column 9: Column1 (unknown column name, REMOVED) [mode=Raw]","mode":"Raw","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Body | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Metadatenidentität | 95f53543cec0c498123baba741394b513842f4b045d2c07d18aa18845ef22499 |
| Response | be326ae6e660d847bdeccfaea1921d626528d08b3070cccc7e403965b33474ee (122 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a927ffec8cb2b8a903b5410d87cbbdc7600d50cf605072421eac9315a7e3605e |

### V2-EDX-017

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `5822370c-ac3c-4d6a-b7d8-89c5f931debf`; Quellbeobachtung `JCR-EDX-021-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-017.json) · [Request](evidence/4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 9: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Body | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Metadatenidentität | 8c53dbd6e19ac987bf0a9e38fddba67b2afb9c85ffdcc30daebc7f027f985eb0 |
| Response | b8a1db91985483ca56949d9c74e92fc1722da23662cc2c70f6d76d2234e8816e (122 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 8ab03bf2e2948c6c740eaf5a7f76fc84292697274c99dd03bb94331dec91e77d |

### V2-EDX-018

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `40ce5520-fc75-4ac1-8f4b-35ace11e18dd`; Quellbeobachtung `JCR-EDX-021-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-018.json) · [Request](evidence/4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 9: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Body | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Metadatenidentität | ce2897b5f40ac9f38ec7445c0fe5066ba95d18bd72a40948e5769b15c68e4852 |
| Response | b8a1db91985483ca56949d9c74e92fc1722da23662cc2c70f6d76d2234e8816e (122 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 4f69723f30df3fba8a9ec23784952fd0ad9bbd62f4c77a3e1b8e87fecd21620f |

### V2-EDX-019

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `b2267185-d9a5-4747-a46c-c790f93289b4`; Quellbeobachtung `JCR-EDX-021-contract_state_control`. [Provenienz und Header](provenance/V2-EDX-019.json) · [Request](evidence/4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{
  "Code": 0,
  "Message": null,
  "Warning": "column 9: Column1 (unknown column name, REMOVED) [mode=Raw]",
  "Mode": "Raw",
  "Data": null
}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Body | 4108de51d662ba0564f14560c190d02f18f194ecf182fd6288c44f3c7a469b5b |
| Request-Metadatenidentität | 1c4db84799355d3e04d9f9b5c9afeac7d0c74b71d235fbfa30e208c6306a48ea |
| Response | c0125698f484cb85bc1859c032835a8057577267b2c2d215af4b26525c5761ed (143 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 6b55a9b0089c7903d568179874f8bb2b4b618e1486a6f4cd524ad8c7e75d7035 |

### V2-EDX-020

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `6121edf6-f831-4b55-8c2b-3c2e9971756f`; Quellbeobachtung `JCR-EDX-024-original`. [Provenienz und Header](provenance/V2-EDX-020.json) · [Request](evidence/45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Body | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Metadatenidentität | 8ab5a7c4bf38ea050b095527116085d1640ab47ec22bddb1f902f15ca51b9d44 |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 8041e8a05c7d8a1203d045d7aa22acd61469cf7cf4d1acefa20d2204cc1f33bd |

### V2-EDX-021

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `3ae7ced4-7f05-48bc-8281-72cb4220223b`; Quellbeobachtung `JCR-EDX-024-conforming`. [Provenienz und Header](provenance/V2-EDX-021.json) · [Request](evidence/45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"RawNoFooter","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Body | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Metadatenidentität | 4299254bfae3741897dabb25efd083582d922c619d7b4ebf84a657c98a5f44a4 |
| Response | 94630985f6a3e663697646e14df368a9235879dce54ed894ceb9c760cc01f1d2 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 9f980ac6f0f5a01b3fc2c18f852b3a9269602545005d07d0fa7eeb169fe4aeb3 |

### V2-EDX-022

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `1c1e6b69-4203-4cf9-b7fe-ca664001e2a6`; Quellbeobachtung `JCR-EDX-024-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-022.json) · [Request](evidence/45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Body | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Metadatenidentität | a8f1131d3283ec5d2b221c4a5ff89ed16270236fdbc572ae74fe2846c71c5050 |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 441a0f1a4dc340005adcc0f1827b2ed54fb046593c27b413e6c1827caa3d1cd3 |

### V2-EDX-023

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `73be9be8-598b-4c75-93fe-f1dee2631c5e`; Quellbeobachtung `JCR-EDX-024-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-023.json) · [Request](evidence/45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Body | 45d94bd1889cef14ff9f42c9c5dbf49256e3c54d39535121a1e7efdb082eecf8 |
| Request-Metadatenidentität | ed0a9624f9a49c6a53771ac32774f5f6de4fedb44b629502b3d618e957aeb76c |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 014869f9739f0ccf6e89fe4b7d3f1328a60eb88445c0fa399380ea01d2dab2d4 |

### V2-EDX-024

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `49a9b605-969d-4277-8165-46aafb046d53`; Quellbeobachtung `JCR-EDX-031-original`. [Provenienz und Header](provenance/V2-EDX-024.json) · [Request](evidence/5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Body | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Metadatenidentität | 9aafdfadf68238dc671351fc9ec09b89a4393b1a9020811a92a3e98578b7a67a |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | e049a9a22e6eca371baf3a137d66904de8dc307f79117f5385af912494b0a919 |

### V2-EDX-025

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `476896c4-b321-44e2-b603-da28cf863978`; Quellbeobachtung `JCR-EDX-031-conforming`. [Provenienz und Header](provenance/V2-EDX-025.json) · [Request](evidence/5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"Raw","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Body | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Metadatenidentität | 04140793589cb8d7e5cf2c523d0f60b6c9c56bcb110ab87cedf042180f592854 |
| Response | 64469cffa1349926de46a729fa185f855c03e1015350262c3a2090e165f7c9f1 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 2e4c97ebf7ced48c8b68214ddb8e1fd24cac12edac0beac63d35ffcbd4179eeb |

### V2-EDX-026

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `bb27fdf7-d995-44f1-8d7c-0f56b5cbfe7b`; Quellbeobachtung `JCR-EDX-031-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-026.json) · [Request](evidence/5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Body | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Metadatenidentität | 262f6e1b0cc5fbe2ab42dcab59d9f1c0e9cb83658332f8640d6db2c66ee314f5 |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d14cb2e0e9e680a0d0833d430d81783235f38454274936fb8b9735aad4ae04ae |

### V2-EDX-027

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `1886e7ec-9f4b-476e-8adb-7d6214d02fc4`; Quellbeobachtung `JCR-EDX-031-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-027.json) · [Request](evidence/5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Body | 5f6135058fe4021fd63e9fd6d9acd59480f0a7fc78d1f769509fcea9d8571cb4 |
| Request-Metadatenidentität | 43934d6ea6f2d21524370dbd1ab3bc6f0a4fd549c6ca80a8d5bdcf63b45dea08 |
| Response | f26b53d0731551c77ea69fa575cecab774dd2b74612ee2e6562a4b389c2437a0 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 1502c38cd1093dd40428d9122294bc3768d7f556f9f0bf508d95a3d4846932df |

### V2-EDX-028

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `51ee0177-5ac5-4edc-a51e-89f6632f7945`; Quellbeobachtung `JCR-EDX-033-conforming`. [Provenienz und Header](provenance/V2-EDX-028.json) · [Request](evidence/680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Body | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Metadatenidentität | 269696f5df5b539ce820fad1f7cad41b4f8bf3e92582a2ff98b512d28d087130 |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-029

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `d77f3781-f9fb-43e8-b6f6-e9281aa5384b`; Quellbeobachtung `JCR-EDX-033-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-029.json) · [Request](evidence/680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Body | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Metadatenidentität | eaeb6269b378acdf2af28e114f591dfcb1e83d54487291cc5061d6b357909504 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-030

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `14ec6c92-afd8-4614-9fc6-4698212c79b1`; Quellbeobachtung `JCR-EDX-033-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-030.json) · [Request](evidence/680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Body | 680f86ec2a83e7a5c213aed11f5d18519f3b307cb8630fb64650cbf88f4b8da5 |
| Request-Metadatenidentität | c1d843bc95e3cb7d9403163968462081d9a99b82be6ed07f1219d03b8cf3603b |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-035

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `3cef1ba3-6285-45d1-bd4a-83d54b17e5c9`; Quellbeobachtung `JCR-EDX-040-conforming`. [Provenienz und Header](provenance/V2-EDX-035.json) · [Request](evidence/87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Body | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Metadatenidentität | 0f217afea8b79927527a8299b63c4eb29cfaa200e70d98d31345afef119dbc54 |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-036

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `42b2897a-fa3b-40a3-9bd7-53a9982d3221`; Quellbeobachtung `JCR-EDX-040-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-036.json) · [Request](evidence/87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Body | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Metadatenidentität | dc2d1a8ffeac0406903b11c585023def321b59973b35dde5768a09fb0aa32478 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-037

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `54cabba7-ea93-407d-8dc8-510de7dbdd9c`; Quellbeobachtung `JCR-EDX-040-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-037.json) · [Request](evidence/87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Body | 87694344ece24e23b50560bb04f34d22f2b3a35d128cc88e8aeac41d5be76a19 |
| Request-Metadatenidentität | 88720c28a52ab46d297cb37a3921acf06806d19b4157407713bf8ef32095c90e |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-038

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `42f16ceb-729e-4451-a6c9-0cfe3f8ac612`; Quellbeobachtung `JCR-EDX-050-conforming`. [Provenienz und Header](provenance/V2-EDX-038.json) · [Request](evidence/b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Body | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Metadatenidentität | 2ee11c481b656c606a7432b080a396c3ea21e19e369188e6a80c245e449f841d |
| Response | 9c79a1ec2f25c15c10a0bfbca1a8bee7bac1ba96d17fec331a76855751783859 (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a711c8ea2536dcbc4de0359721453a986364ae864048accd3ebc032f01f264c9 |

### V2-EDX-039

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `5a62b345-99a6-470c-8dde-20fe2e977534`; Quellbeobachtung `JCR-EDX-050-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-039.json) · [Request](evidence/b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Body | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Metadatenidentität | 9d6ccfadf8f5d77d6dd6699c86bf5d83745a89aac159f1a4d63893e26338607f |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | d354518b9d50e48590c7d50326e0786cddda23cb7f5db436ed13613bdff32257 |

### V2-EDX-040

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `331ad34c-ad41-47f4-a4d6-6d7636d29a4c`; Quellbeobachtung `JCR-EDX-050-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-040.json) · [Request](evidence/b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Body | b98db23d29a7d7ee2a47e7db434172c20dc4156985faafd6a4d6c79233416ddd |
| Request-Metadatenidentität | 0a343572b747e14b80536857904572c3314da0398a446e348074922d3c073bf9 |
| Response | c9b5c8363abd3f59000db18a34419280f2f78382f4208f761f6ac7e294a533fe (65 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 07b90116eaee1a2496b5ea1d2d8ac5c86af6f7c44ac115339264d814e5e707d7 |

### V2-EDX-049

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `63f1d947-9e47-408f-8f7b-3f9da3731ce9`; Quellbeobachtung `JCR-EDX-060-original`. [Provenienz und Header](provenance/V2-EDX-049.json) · [Request](evidence/d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 6: Total (TOTAL column name, REMOVED) [mode=CSV]","Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Body | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Metadatenidentität | 4ade22508f81c3e9249b5c8d0469bff9bbcef415a7900602373e00eae0af063b |
| Response | b02ad0a446a5e6090f5f2e8e2fb4e5667248fe0a9c9fcb328d86993336fee9ee (118 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 4ab54e2e449083a5c14f02d7da033c677c3793bef06294562b447a4af0bff324 |

### V2-EDX-050

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `90ff1137-06a6-4dad-88a5-1e9e0ffbecf1`; Quellbeobachtung `JCR-EDX-060-conforming`. [Provenienz und Header](provenance/V2-EDX-050.json) · [Request](evidence/d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":"column 6: Total (TOTAL column name, REMOVED) [mode=CSV]","mode":"CSV","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Body | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Metadatenidentität | ed7e4819bf767e1877aad27a77e46e66d2e06ed5cee8b9edbc48e2088cd6c59c |
| Response | 73479bf638383035153eed5110c6b1368c226fad98b6c3a34ab5f22dda23e548 (118 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | a03fd691fbde2c667740af4067e94d49d3b7f7af1f7ee67cefde43355ca9f640 |

### V2-EDX-051

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `869f5ebd-2cbd-462d-8e46-b44a5c460226`; Quellbeobachtung `JCR-EDX-060-c1_regressive`. [Provenienz und Header](provenance/V2-EDX-051.json) · [Request](evidence/d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 6: Total (TOTAL column name, REMOVED) [mode=CSV]","Mode":"CSV","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Body | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Metadatenidentität | 909fbfae9d9377761c8183898adde36214186c3e6a8d3d4682138f6f321af034 |
| Response | b02ad0a446a5e6090f5f2e8e2fb4e5667248fe0a9c9fcb328d86993336fee9ee (118 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | ba7fdac4fbd68cdec0f32024c0e4c2471846695d29bf293d45c1383a93b55f36 |

### V2-EDX-052

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `cb012124-a0d8-4fcb-910c-5c879ff18c3a`; Quellbeobachtung `JCR-EDX-060-c2_regressive`. [Provenienz und Header](provenance/V2-EDX-052.json) · [Request](evidence/d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"column 6: Total (TOTAL column name, REMOVED) [mode=CSV]","Mode":"CSV","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Body | d74605198e0a6d736f93da90e2c609007813df8002f5f3f7225324f3b4705c99 |
| Request-Metadatenidentität | d529822aa1d5f78fc8d588603cb10bbaf020983fa4c515f6da2b33d3e00b642f |
| Response | b02ad0a446a5e6090f5f2e8e2fb4e5667248fe0a9c9fcb328d86993336fee9ee (118 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 792783a59e5db8f47b31d7566f419dc20046033d386ce2807d46f18f1b7d16c4 |

### V2-EDX-045

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `52eafe02-05de-4062-a2e6-03faad64843b`; Quellbeobachtung `RV3-DISC-005`. [Provenienz und Header](provenance/V2-EDX-045.json) · [Request](evidence/d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 6: Column1 (unknown column name, REMOVED) [mode=Raw] column 7: Column2 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Body | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Metadatenidentität | c715b88a3160d18db0e285c0218f534ae5086a91b29271f39b7430741cf9d27e |
| Response | 05cabfa8139b9a9177e6aba392f13d8a36edf95cdb5109ad94ee2a1afdf5508c (316 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 26eabd1b8789f2447d2777b72ec0a155d858a79c0f3255d42e128e55368aa893 |

### V2-EDX-046

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `9cd3a863-8891-465e-804c-b2a3dd5ef751`; Quellbeobachtung `RV3-DISC-006`. [Provenienz und Header](provenance/V2-EDX-046.json) · [Request](evidence/d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 6: Column1 (unknown column name, REMOVED) [mode=Raw] column 7: Column2 (unknown column name, REMOVED) [mode=Raw]","mode":"Raw","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Body | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Metadatenidentität | c41c9577b34fc6e3bb05b6f286b7340670e3cdfa4cbf5d50cfc67f38955a8ec0 |
| Response | 88496ee99063ed890c888d9ff33988c8a89f1559a730d6c8334da8312b3c2ad5 (316 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 5016f0a3fcf043b347731c7ca6aff5ce19165324298f87697639969a6b626e2f |

### V2-EDX-047

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `6d57cdca-db4d-4d89-a31a-9303dccdd769`; Quellbeobachtung `RV3-DISC-007`. [Provenienz und Header](provenance/V2-EDX-047.json) · [Request](evidence/d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 6: Column1 (unknown column name, REMOVED) [mode=Raw] column 7: Column2 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Body | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Metadatenidentität | bfde9fcf2ad1c8aa71d8feb3838b10803e697ab24238ebd8dea21f4b90c464e8 |
| Response | 05cabfa8139b9a9177e6aba392f13d8a36edf95cdb5109ad94ee2a1afdf5508c (316 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 0e8e38d9a1c92669fb52753fae94ecf4e11c2df66ec2edb8871b6bb319438119 |

### V2-EDX-048

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `f7f4ef70-edd5-40a4-a465-20f6a5e18d1b`; Quellbeobachtung `RV3-DISC-008`. [Provenienz und Header](provenance/V2-EDX-048.json) · [Request](evidence/d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 6: Column1 (unknown column name, REMOVED) [mode=Raw] column 7: Column2 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Body | d0f22e9d82d94f8af1613a6cdcf2ba688555106f323837ab8055441ae354e518 |
| Request-Metadatenidentität | 1a51d9fb807af33711eafe662469530a6b360f1a11a66abcffc9a9c816d6600a |
| Response | 05cabfa8139b9a9177e6aba392f13d8a36edf95cdb5109ad94ee2a1afdf5508c (316 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 5a6be7dd10b2bc299c17b6600abeeadaf2d35c42941d81f30bf658ef712fc9cb |

### V2-EDX-041

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `dec56300-a2c5-4ff6-beab-1e849580c53c`; Quellbeobachtung `RV3-DISC-009`. [Provenienz und Header](provenance/V2-EDX-041.json) · [Request](evidence/c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 12: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Body | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Metadatenidentität | 6d3545f8a9e0289a085ca280f1fb84c6c2b28b9f5dc6397b0b935063078db74f |
| Response | 565ea8df493441a03af9c5a66a860a1cbe65b39f11baf652e28de9757f9de3ac (257 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 7b3360835f70b6092b07c61c75ae03d6c234317797088b6c5fdc9dea2a438915 |

### V2-EDX-042

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `09701720-bbf9-457c-a2ae-55cc52417a2a`; Quellbeobachtung `RV3-DISC-010`. [Provenienz und Header](provenance/V2-EDX-042.json) · [Request](evidence/c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 12: Column1 (unknown column name, REMOVED) [mode=Raw]","mode":"Raw","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Body | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Metadatenidentität | f8d2cba234f1d098c85536edc0a4774421a3cdeeacb3c6e24e7150ab23061e1a |
| Response | 295e1f733f771e5dca967154e2049f4ed1b85a7a1ca9683aec825e732c4c5154 (257 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 65ea04225c3d27245964ec73f13556b5ca0488a7796bca599952638e8684a872 |

### V2-EDX-043

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `fd223176-e2c3-48a4-9310-638134f9a6d8`; Quellbeobachtung `RV3-DISC-011`. [Provenienz und Header](provenance/V2-EDX-043.json) · [Request](evidence/c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 12: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Body | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Metadatenidentität | 59bc15a4cc31b811907369eb58a826ebcdd51020908086382098d40e009a30ff |
| Response | 565ea8df493441a03af9c5a66a860a1cbe65b39f11baf652e28de9757f9de3ac (257 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | ad3d9e47959be1af84c7c61cb32af1d01bbf509e23fa2d1b0c4b504ea66d7d13 |

### V2-EDX-044

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `60d24675-7e1c-4f54-a37d-4fa83946e447`; Quellbeobachtung `RV3-DISC-012`. [Provenienz und Header](provenance/V2-EDX-044.json) · [Request](evidence/c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"raw file (multiple data portions: several \"Processing option\" or \"Mean\" detected - consider first fragment) [mode=RawNonStandard] column 12: Column1 (unknown column name, REMOVED) [mode=Raw]","Mode":"Raw","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Body | c5cd5c3099862b0780a75d704c02935f33dd31af105ae2a9299a58d6f0679040 |
| Request-Metadatenidentität | 91a825670024383ba5fd7482ea15e5635cc27782bb73c786b4aea2534d803f50 |
| Response | 565ea8df493441a03af9c5a66a860a1cbe65b39f11baf652e28de9757f9de3ac (257 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | aed30830be6980b4e263abb6a85961fd80a806267ea73183baadc9df5fde7726 |

### V2-EDX-031

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `32b2ae70-ddb2-4557-a09a-eda2428eac79`; Quellbeobachtung `RV3-DISC-013`. [Provenienz und Header](provenance/V2-EDX-031.json) · [Request](evidence/75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 FAIL:** Parsed object contains uppercase properties not allowed by the lowercase schema with additionalProperties=false; lowercase properties are optional, not missing required fields.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Body | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Metadatenidentität | b8f362317be8538c6b45fd2d7234d3072d0375de986791efcb42b1736b83578f |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 8041e8a05c7d8a1203d045d7aa22acd61469cf7cf4d1acefa20d2204cc1f33bd |

### V2-EDX-032

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `385b7e33-5c35-4646-833a-8cccaaa1d163`; Quellbeobachtung `RV3-DISC-014`. [Provenienz und Header](provenance/V2-EDX-032.json) · [Request](evidence/75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"code":0,"message":null,"warning":null,"mode":"RawNoFooter","data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; charset=utf-8; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1edx~1validation~1body/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Body | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Metadatenidentität | 3bf99e52995dd462dadbf2b314e91ae5381bedc37635e47bc18ad6ea02640db0 |
| Response | 94630985f6a3e663697646e14df368a9235879dce54ed894ceb9c760cc01f1d2 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 9f980ac6f0f5a01b3fc2c18f852b3a9269602545005d07d0fa7eeb169fe4aeb3 |

### V2-EDX-033

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `6e5ac283-f288-4234-88af-ae8ba372b821`; Quellbeobachtung `RV3-DISC-015`. [Provenienz und Header](provenance/V2-EDX-033.json) · [Request](evidence/75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 FAIL:** HTTP 201 has no documented response branch (including range/default).
- **C2 NOT_APPLICABLE:** Not applicable because C1 FAIL.
- **C3 NOT_APPLICABLE:** Not applicable because C1 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Body | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Metadatenidentität | 4a75baf892ca26aba8923e8cce3a6318efc6df44d1921554aa59cc80b6239380 |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 441a0f1a4dc340005adcc0f1827b2ed54fb046593c27b413e6c1827caa3d1cd3 |

### V2-EDX-034

**PENDING.**

Operation `POST /edx/validation/body`; Ausführung `a0173253-dc15-492e-9260-d3247ea033b6`; Quellbeobachtung `RV3-DISC-016`. [Provenienz und Header](provenance/V2-EDX-034.json) · [Request](evidence/75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a.bin) · [OpenAPI](contracts/4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"RawNoFooter","Data":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Body | 75451f4023ea70fc6eabbb1905eba8fe629290b9bec79765eefb0d287eab8a2a |
| Request-Metadatenidentität | eea0d725d13d8a47b61543eba1d01086500763c94ad7e15b0406ec934c261241 |
| Response | c2795e253b02cae8683b3945fdd4350b3589c476fe1a75430141e28caa848c26 (73 Bytes) |
| OpenAPI | 4fb9c2bf81b401463dcd66f463c214a3019b75b48f0a88db1cf541a770ea4fbc |
| Gerenderter Evidenzkontext | 014869f9739f0ccf6e89fe4b7d3f1328a60eb88445c0fa399380ea01d2dab2d4 |

### V2-RES-001

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `31b7979b-e9c0-47fa-9c28-2740ce4c4325`; Quellbeobachtung `RV3-RES-C2-001`. [Provenienz und Header](provenance/V2-RES-001.json) · [Request](evidence/df59f1c899a5dfd65b6bbd23c2f50787a98c17aa226e6ec2b046914d6aeb5aea.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 11262f6cdedbb3b787bd344303987b92dff104c2bd30ba24751c78e427409f77 |
| Request-Body | df59f1c899a5dfd65b6bbd23c2f50787a98c17aa226e6ec2b046914d6aeb5aea |
| Request-Metadatenidentität | 102c72a6a1b34ce999628baf4039e9d2a3cb31ea46bf2e1b2f834e5d7e19613e |
| Response | 544040be9b9f23840bde2d84af4b352a1fb368e7699078125718984dcba3b88e (74 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 10193e300571c8c8ff278052bedb72ff035e38413daedd39e986a7867c290cdd |

### V2-RES-002

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `a7f7ae66-58f7-42a2-94cc-6c3fb1e321e6`; Quellbeobachtung `RV3-RES-C2-020`. [Provenienz und Header](provenance/V2-RES-002.json) · [Request](evidence/df59f1c899a5dfd65b6bbd23c2f50787a98c17aa226e6ec2b046914d6aeb5aea.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 11262f6cdedbb3b787bd344303987b92dff104c2bd30ba24751c78e427409f77 |
| Request-Body | df59f1c899a5dfd65b6bbd23c2f50787a98c17aa226e6ec2b046914d6aeb5aea |
| Request-Metadatenidentität | 6a3f12ee42d17224c8bd31fda099061ba336e550313c40b872edcb403243a68e |
| Response | 544040be9b9f23840bde2d84af4b352a1fb368e7699078125718984dcba3b88e (74 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 58ff56f04af28ea349d772e8778fb3c319b67d98f354a5d027c93417d6cf29e1 |

### V2-RES-008

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `8b6c2e04-7aff-4813-90be-6020daf7c10a`; Quellbeobachtung `RV3-RES-C2-021`. [Provenienz und Header](provenance/V2-RES-008.json) · [Request](evidence/8ecd93f65f18c59d43a16f0acf7dfcbaef66635ec74177ac1a22991a6f55fd9b.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Triple-R, Tab-delimited"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3669cf1396ca1d66cac838b0631227613b704336c85811495dbeeb92e5998455 |
| Request-Body | 8ecd93f65f18c59d43a16f0acf7dfcbaef66635ec74177ac1a22991a6f55fd9b |
| Request-Metadatenidentität | 1247ce5aed8fecb1df35202caaf686faba126fe378899cb6fde041ad01f908da |
| Response | 262d14caaa49f8bebe026dc18c2728b449829ac5fad7558e31559d2b9d4e53c0 (121 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | f109593bf6466b28d2eba53dbfab2143e94bf7431f401206ec9076fea1a60b2c |

### V2-RES-011

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `1aae46a2-5b0d-4bea-ae7c-3e56dd4a59f2`; Quellbeobachtung `RV3-RES-C2-003`. [Provenienz und Header](provenance/V2-RES-011.json) · [Request](evidence/777e2adc8462b1ee2f4945e455c3193feeb3f988207950a5f4b8e157b68fe8cb.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"The file is valid, but incomplete: fewer than 342 unique coordinates were found, so full MA coverage is not available.","Mode":"Triple-R Linescan"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 44b94c8da88adea473b91f6abae9d30dfad4cde260ffe6d69d989c80fbd112a9 |
| Request-Body | 777e2adc8462b1ee2f4945e455c3193feeb3f988207950a5f4b8e157b68fe8cb |
| Request-Metadatenidentität | bfbd3133a02c8e8eceeca283d6672fb7d31971f0c113e2c3b5f4b29c9cf31144 |
| Response | fdc0f6ba816d4590bad15a6357d0cd6aa5c9d345063e21553ffedaecbf0a4c83 (183 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 4621fc899c38542ae85c9d1f64cfb27491a2b6bc3c45fb55ca602a074396c592 |

### V2-RES-012

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `0e8a1370-12ad-42f5-aad7-3156fcc9efa4`; Quellbeobachtung `RV3-RES-C2-022`. [Provenienz und Header](provenance/V2-RES-012.json) · [Request](evidence/777e2adc8462b1ee2f4945e455c3193feeb3f988207950a5f4b8e157b68fe8cb.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"The file is valid, but incomplete: fewer than 342 unique coordinates were found, so full MA coverage is not available.","Mode":"Triple-R Linescan"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 44b94c8da88adea473b91f6abae9d30dfad4cde260ffe6d69d989c80fbd112a9 |
| Request-Body | 777e2adc8462b1ee2f4945e455c3193feeb3f988207950a5f4b8e157b68fe8cb |
| Request-Metadatenidentität | 3bfe9a13fd8b55033af63cb6d340cff063db2e7f2e69e2c779bf4eff424551b1 |
| Response | fdc0f6ba816d4590bad15a6357d0cd6aa5c9d345063e21553ffedaecbf0a4c83 (183 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 8aec6836fde6d546b1866c52be52de07a81b70c32a9170e56d474d0a7619b886 |

### V2-RES-013

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `a424757d-d755-4496-ae98-66835f70c2c6`; Quellbeobachtung `RV3-RES-C2-004`. [Provenienz und Header](provenance/V2-RES-013.json) · [Request](evidence/717c3672d15b30a605fc6f3d717041935e4999b79172b487dca2725a811511cd.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Multi-R, Room Temperature"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 6761e17423ac84dbbcf806e303b4822baf3b12759210d49ad118531b38b30315 |
| Request-Body | 717c3672d15b30a605fc6f3d717041935e4999b79172b487dca2725a811511cd |
| Request-Metadatenidentität | 29294ffb16309a051bae4c3aa690107c78415c28e4c3b323d4d13356911855d3 |
| Response | a5619a04464f3d570c3b2d1604651a2a0d34419ea192a45b155a709910c1350d (75 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | cfc3fa0eeb27bdb3b187cb407785730d5af2c342840c9b3cb350c9d46d91e3ed |

### V2-RES-014

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `0baea040-b469-44b1-8a70-3d8452c3742f`; Quellbeobachtung `RV3-RES-C2-023`. [Provenienz und Header](provenance/V2-RES-014.json) · [Request](evidence/717c3672d15b30a605fc6f3d717041935e4999b79172b487dca2725a811511cd.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Multi-R, Room Temperature"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 6761e17423ac84dbbcf806e303b4822baf3b12759210d49ad118531b38b30315 |
| Request-Body | 717c3672d15b30a605fc6f3d717041935e4999b79172b487dca2725a811511cd |
| Request-Metadatenidentität | 5ce435ef80a878a4ebaa917c2ff308ae486e824850e4d53b2ba5a2ba31b688a5 |
| Response | a5619a04464f3d570c3b2d1604651a2a0d34419ea192a45b155a709910c1350d (75 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 8e81a9e9c7c9bfb95039c72a84d44258bf1cda1c4a95052e8fcfb86fae8b4991 |

### V2-RES-015

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `f753db31-6c7a-4df1-aca9-17f7afae0413`; Quellbeobachtung `RV3-RES-C2-005`. [Provenienz und Header](provenance/V2-RES-015.json) · [Request](evidence/5e606d016f00e76c24616649acbf847999745031171af407ede39d187cb82304.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"T-Dependent, Temperature Sweep"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 85bd34c189c9b49367fd9d64a00cefa310e58fdd6d3b74cb74c1cb2f9ed664e1 |
| Request-Body | 5e606d016f00e76c24616649acbf847999745031171af407ede39d187cb82304 |
| Request-Metadatenidentität | b1f77e2e55d0b5de88a12038691e64715daaf5f523f5eaa0136ad26eac5dcc21 |
| Response | 9724c622f13b23d933dc0e2392610ded592c993980c9701ae7b7182e5d62f43e (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 8184678cabb1930d2b0b82277428fe0618e55ada9dae4ed4b5ad5451526798df |

### V2-RES-016

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `2dd67fd2-5ce9-4265-8e0a-365281896bb2`; Quellbeobachtung `RV3-RES-C2-024`. [Provenienz und Header](provenance/V2-RES-016.json) · [Request](evidence/5e606d016f00e76c24616649acbf847999745031171af407ede39d187cb82304.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"T-Dependent, Temperature Sweep"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 85bd34c189c9b49367fd9d64a00cefa310e58fdd6d3b74cb74c1cb2f9ed664e1 |
| Request-Body | 5e606d016f00e76c24616649acbf847999745031171af407ede39d187cb82304 |
| Request-Metadatenidentität | d524e7dc7bf1a9745548a5c9b3670c8480d7a3b369f45382323a4e14d4ab3317 |
| Response | 9724c622f13b23d933dc0e2392610ded592c993980c9701ae7b7182e5d62f43e (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 57dfe7580308525388a3febe1a318fdfcb141b3c1dd44835f0a72fdb0069ce4e |

### V2-RES-017

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `473ba496-ab7b-4926-8d51-eeb2122d057d`; Quellbeobachtung `RV3-RES-C2-006`. [Provenienz und Header](provenance/V2-RES-017.json) · [Request](evidence/69690e6635a949ed2f42fe64d32451bd1b2b5920b3ad930801b0e61f18da68d0.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Single-R, MA Index with Header"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 93b835a47ef0d40c225e9e665b0e0e9218595d43e3b4358145ac6ef6200c5a70 |
| Request-Body | 69690e6635a949ed2f42fe64d32451bd1b2b5920b3ad930801b0e61f18da68d0 |
| Request-Metadatenidentität | 4ae74b90294d1b202bb34b9fca592345ec1e84a1c911c302d1dc504fad1f478e |
| Response | de345ee281f0a25761529585e1b5a2813dcabb152f17cf4f92e2f9da56ed83c9 (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 8d2c0538c41b781aa0b4f3f439900423435158c3c47dd56bca78f404eb763e4f |

### V2-RES-018

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `82c7463b-f06a-4dba-b4f1-7e6b60f6326c`; Quellbeobachtung `RV3-RES-C2-025`. [Provenienz und Header](provenance/V2-RES-018.json) · [Request](evidence/69690e6635a949ed2f42fe64d32451bd1b2b5920b3ad930801b0e61f18da68d0.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Single-R, MA Index with Header"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 93b835a47ef0d40c225e9e665b0e0e9218595d43e3b4358145ac6ef6200c5a70 |
| Request-Body | 69690e6635a949ed2f42fe64d32451bd1b2b5920b3ad930801b0e61f18da68d0 |
| Request-Metadatenidentität | 950913e3d80016ecae74e73320ff03c0e872114c2f42cc7127c4ecdd73f01096 |
| Response | de345ee281f0a25761529585e1b5a2813dcabb152f17cf4f92e2f9da56ed83c9 (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | f152159d6d528452d29cfa26041908b80aba7dfe48ccd572cabb6ed5826179ca |

### V2-RES-023

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `41121e38-5d77-44bc-88cf-f68cd2d6dec1`; Quellbeobachtung `RV3-RES-C2-007`. [Provenienz und Header](provenance/V2-RES-023.json) · [Request](evidence/14f34d5756573cf0fc67b3c885da47af44df7eb89c62a8f18198da8fb27ab0a7.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Full-Array, T-Dependent"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | b44577ff11323d88964bb06292d0b44b0c649f2a5dbc1c0a77d806070df405f0 |
| Request-Body | 14f34d5756573cf0fc67b3c885da47af44df7eb89c62a8f18198da8fb27ab0a7 |
| Request-Metadatenidentität | 02fe2277d12baf138acbab8e5687e7cb6be79ba6a980d1c98bb5118886aa40c6 |
| Response | dfa78ba03d61fe692310fe28d88d28d7fda723eac9389aa05563bfb6951fa38a (73 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 17029f5d57c87292ece079049bcb849afc276d2eab3a1ac6f85d8e47f9428813 |

### V2-RES-024

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `1a635812-eee0-467f-8270-0d34b04976bc`; Quellbeobachtung `RV3-RES-C2-026`. [Provenienz und Header](provenance/V2-RES-024.json) · [Request](evidence/14f34d5756573cf0fc67b3c885da47af44df7eb89c62a8f18198da8fb27ab0a7.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Full-Array, T-Dependent"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | b44577ff11323d88964bb06292d0b44b0c649f2a5dbc1c0a77d806070df405f0 |
| Request-Body | 14f34d5756573cf0fc67b3c885da47af44df7eb89c62a8f18198da8fb27ab0a7 |
| Request-Metadatenidentität | a42f514c5682125300a55b069187c30c3f0c434395dbc0669c45ede9867de6e1 |
| Response | dfa78ba03d61fe692310fe28d88d28d7fda723eac9389aa05563bfb6951fa38a (73 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | ce9625dc9003d0fa9a14eb6f76c2082dcc11f3d8e955fba4ad10e89e9a9563d6 |

### V2-RES-025

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `ac354087-6388-4260-af94-a4119dc2bb17`; Quellbeobachtung `RV3-RES-C2-008`. [Provenienz und Header](provenance/V2-RES-025.json) · [Request](evidence/83f3736bcd86549c5d63cb16066e4204de881b73c8f80cdf20a7510da4a20b7e.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV with Extra Columns"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | bbeaf387a189a46bde8e35168edc74944096659a2edff1aa25532bc02867b3af |
| Request-Body | 83f3736bcd86549c5d63cb16066e4204de881b73c8f80cdf20a7510da4a20b7e |
| Request-Metadatenidentität | d2c833703c6df1de1835fe742a228188e2c5ddbd437fed8a16cbae2fde3fa856 |
| Response | 5b5b9e8d99ce130a15c89e9020c5283578e17d02b087342cac87d986c8bfc73a (93 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 70d3b53d72a89406300f93c68981b28dc3047be7bacc1c70ba5e4e6caac2b215 |

### V2-RES-026

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `c6dc7ca1-0573-473f-9d30-7acbac13fad3`; Quellbeobachtung `RV3-RES-C2-027`. [Provenienz und Header](provenance/V2-RES-026.json) · [Request](evidence/83f3736bcd86549c5d63cb16066e4204de881b73c8f80cdf20a7510da4a20b7e.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV with Extra Columns"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | bbeaf387a189a46bde8e35168edc74944096659a2edff1aa25532bc02867b3af |
| Request-Body | 83f3736bcd86549c5d63cb16066e4204de881b73c8f80cdf20a7510da4a20b7e |
| Request-Metadatenidentität | 39748ee73951c46cdcae086cec0237662e0223923653f4c8b672167f03a8eca3 |
| Response | 5b5b9e8d99ce130a15c89e9020c5283578e17d02b087342cac87d986c8bfc73a (93 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | e73f8d6bf7a855f6669582c56e70015a37046e27ec7ffebab74c08aeb865bafc |

### V2-RES-029

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `62c02c9c-9ec8-4941-82ff-63764cd42dbe`; Quellbeobachtung `RV3-RES-C2-012`. [Provenienz und Header](provenance/V2-RES-029.json) · [Request](evidence/f734cf93e24778f9f7aa082af614fee32e8023cadebdc45436590e0f2f8eda47.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Single-R, MA Index"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `NEW_INPUT_BYTES`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | fd87f687714fd9ad7a09f8f57dfbbacf66abe78ec1fdb58dacf5439b22d32364 |
| Request-Body | f734cf93e24778f9f7aa082af614fee32e8023cadebdc45436590e0f2f8eda47 |
| Request-Metadatenidentität | e509c98a5c3825acce5cc77c158396c3d8f2c34850f9da9109b3013521e01d6f |
| Response | 236aacfa3433ee2eb20baad5c16612ee91b2a3f2689e0ffa7d10dcb746c7feb9 (116 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 221fb5c66f97103615dd36a6fcd9bf237688838735e3da30c281d7eb54e14366 |

### V2-RES-030

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `2b3b1372-1bd1-4ecf-a2a5-8d38b712b7ca`; Quellbeobachtung `RV3-RES-C2-031`. [Provenienz und Header](provenance/V2-RES-030.json) · [Request](evidence/f734cf93e24778f9f7aa082af614fee32e8023cadebdc45436590e0f2f8eda47.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Single-R, MA Index"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `NEW_INPUT_BYTES`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | fd87f687714fd9ad7a09f8f57dfbbacf66abe78ec1fdb58dacf5439b22d32364 |
| Request-Body | f734cf93e24778f9f7aa082af614fee32e8023cadebdc45436590e0f2f8eda47 |
| Request-Metadatenidentität | 061edde215c623e59d52168cf68433fbada3fcfea9e0bea2a0913ac46bb7b831 |
| Response | 236aacfa3433ee2eb20baad5c16612ee91b2a3f2689e0ffa7d10dcb746c7feb9 (116 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 9a44fc4f8d2b19763ec79cfa826cf4a57a958fa2f9d2c1284f34371dacefba01 |

### V2-RES-003

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `cab5114e-0c70-44f7-ae0e-0f10de35ddd0`; Quellbeobachtung `RV3-RES-C2-013`. [Provenienz und Header](provenance/V2-RES-003.json) · [Request](evidence/a0c90c415b3edff595b6dd081e521ff4a47ca8a7f0f5e2786bd4362fa26d91c1.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Triple-R, Tab-delimited with Temperature Readout"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `NEW_INPUT_BYTES`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 11e1fd2930da67ea06636803c1f7727c15fb7abf64d4aa5f5f6731457bd51f24 |
| Request-Body | a0c90c415b3edff595b6dd081e521ff4a47ca8a7f0f5e2786bd4362fa26d91c1 |
| Request-Metadatenidentität | 35384984a84a87ab74685c71cf8c040fa33ee004199dc51eae79b342208f9100 |
| Response | 0eef6462ed60df6c8882ebc53997011e08afbd27a12bf864187434920992dd04 (146 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | a4d3e0239e67822f30577ac97f8b1da71dbdec01754b48114e67754d4df83b14 |

### V2-RES-004

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `4d6602c9-9262-4f12-8eb6-0c21eade1a4f`; Quellbeobachtung `RV3-RES-C2-032`. [Provenienz und Header](provenance/V2-RES-004.json) · [Request](evidence/a0c90c415b3edff595b6dd081e521ff4a47ca8a7f0f5e2786bd4362fa26d91c1.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Triple-R, Tab-delimited with Temperature Readout"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `NEW_INPUT_BYTES`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 11e1fd2930da67ea06636803c1f7727c15fb7abf64d4aa5f5f6731457bd51f24 |
| Request-Body | a0c90c415b3edff595b6dd081e521ff4a47ca8a7f0f5e2786bd4362fa26d91c1 |
| Request-Metadatenidentität | cda7daece9355ebcce193bfe360fae157d81db74cf6cdd188e741f3306a1fd84 |
| Response | 0eef6462ed60df6c8882ebc53997011e08afbd27a12bf864187434920992dd04 (146 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 3b399d1b4b90ae474e4a808cc3884ddecf7dc3da9b948261473aa097ea54a9d0 |

### V2-RES-007

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `f1164901-440f-46b8-b636-2ff148d2055d`; Quellbeobachtung `RV3-RES-C2-033`. [Provenienz und Header](provenance/V2-RES-007.json) · [Request](evidence/e0f95de84c9a3d7d8c78330c528e33a0f2eba9fc998e7c451b51cc365ccb1b2a.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":"Columns names are inferred from the file structure","Mode":"Triple-R, Tab-delimited"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 1f27cfb5bdc3b1d5d388d84c106ce3d38ac06c6574a28f8eccf365777f6df802 |
| Request-Body | e0f95de84c9a3d7d8c78330c528e33a0f2eba9fc998e7c451b51cc365ccb1b2a |
| Request-Metadatenidentität | d2c77342f1e623b58b86e382975e781b0e7f05f242e8b362e7bbc199992cf9c1 |
| Response | 262d14caaa49f8bebe026dc18c2728b449829ac5fad7558e31559d2b9d4e53c0 (121 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | f109593bf6466b28d2eba53dbfab2143e94bf7431f401206ec9076fea1a60b2c |

### V2-RES-009

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `22b30582-cde9-4ad4-9fed-7f820bdf43ab`; Quellbeobachtung `RV3-RES-C2-015`. [Provenienz und Header](provenance/V2-RES-009.json) · [Request](evidence/3bee6a054a2c2efc741092a6671fe05fae9974faf5dc580b96247fff500f374d.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV with Extra Columns"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3b0eb508bd2d5b7081bc0ec8b18f4286d6dc594e8fce0c6d3552bab08e537861 |
| Request-Body | 3bee6a054a2c2efc741092a6671fe05fae9974faf5dc580b96247fff500f374d |
| Request-Metadatenidentität | 9f293fdd0e6d458d227b92e301ccb1a5a7555c69aa7979fe1c7594bc548fe0ef |
| Response | 5b5b9e8d99ce130a15c89e9020c5283578e17d02b087342cac87d986c8bfc73a (93 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 70d3b53d72a89406300f93c68981b28dc3047be7bacc1c70ba5e4e6caac2b215 |

### V2-RES-010

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `0448cf83-0c40-4b16-abd6-342e3d54ce87`; Quellbeobachtung `RV3-RES-C2-034`. [Provenienz und Header](provenance/V2-RES-010.json) · [Request](evidence/3bee6a054a2c2efc741092a6671fe05fae9974faf5dc580b96247fff500f374d.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Triple-R, Instrument CSV with Extra Columns"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 3b0eb508bd2d5b7081bc0ec8b18f4286d6dc594e8fce0c6d3552bab08e537861 |
| Request-Body | 3bee6a054a2c2efc741092a6671fe05fae9974faf5dc580b96247fff500f374d |
| Request-Metadatenidentität | 52cddfcf5c8af8c68fc8cdc8b8a204b8d13a4e9cb3042fa065b83c525ede65c2 |
| Response | 5b5b9e8d99ce130a15c89e9020c5283578e17d02b087342cac87d986c8bfc73a (93 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | e73f8d6bf7a855f6669582c56e70015a37046e27ec7ffebab74c08aeb865bafc |

### V2-RES-005

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `7ddeba21-f7eb-4071-a910-101c0939524f`; Quellbeobachtung `RV3-RES-C2-017`. [Provenienz und Header](provenance/V2-RES-005.json) · [Request](evidence/e1bc69767915018a17b38ca72a69f757eccedcda2feb266bbb2be2f32ea34b2f.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Single-R, MA Index with Header"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 18d748688bc9667d297075d6a71d5c6a29714a830c41d2b0718b78e88a413c75 |
| Request-Body | e1bc69767915018a17b38ca72a69f757eccedcda2feb266bbb2be2f32ea34b2f |
| Request-Metadatenidentität | a47dcf2c8e6cd39b8e6eabca62bd1856bb78be93b42bf10c771974eee2f3c8d8 |
| Response | de345ee281f0a25761529585e1b5a2813dcabb152f17cf4f92e2f9da56ed83c9 (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 8d2c0538c41b781aa0b4f3f439900423435158c3c47dd56bca78f404eb763e4f |

### V2-RES-006

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `585567ca-a758-411e-ae16-d8c6c082bb1f`; Quellbeobachtung `RV3-RES-C2-036`. [Provenienz und Header](provenance/V2-RES-006.json) · [Request](evidence/e1bc69767915018a17b38ca72a69f757eccedcda2feb266bbb2be2f32ea34b2f.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":0,"Message":null,"Warning":null,"Mode":"Single-R, MA Index with Header"}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 18d748688bc9667d297075d6a71d5c6a29714a830c41d2b0718b78e88a413c75 |
| Request-Body | e1bc69767915018a17b38ca72a69f757eccedcda2feb266bbb2be2f32ea34b2f |
| Request-Metadatenidentität | f8b038af101a86a08e69ca7ceba077b2315cc8028fa5af068a3db7b6ac348430 |
| Response | de345ee281f0a25761529585e1b5a2813dcabb152f17cf4f92e2f9da56ed83c9 (80 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | f152159d6d528452d29cfa26041908b80aba7dfe48ccd572cabb6ed5826179ca |

### V2-RES-019

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `eabfc16b-a992-4199-865e-00649f3df65f`; Quellbeobachtung `RV3-RES-C2-018`. [Provenienz und Header](provenance/V2-RES-019.json) · [Request](evidence/46dd92a3727011e22f780ae9ad9e71c378c57e26fd6c71904ce2d399cde69350.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":300,"Message":"The number of unique coordinates is greater than 342, which is not allowed.","Warning":null,"Mode":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 96b0826c724b532e61432034ec80051e120d997acd694a286f2135ac958396d4 |
| Request-Body | 46dd92a3727011e22f780ae9ad9e71c378c57e26fd6c71904ce2d399cde69350 |
| Request-Metadatenidentität | 5aed24731b9a038b82ca387520f97e340d8f732a2bf433fe2dba6df3168dd39a |
| Response | d699ab4b56bafe6869adc522c03989cd586a93398052361f662fed57cb563cda (127 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 930b44539e67c9b05f2096820c719911c78227d17afc2ff4e8d2c522cc19fa20 |

### V2-RES-020

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `300a5913-2d6a-4903-a990-5d0a8b3e9e6a`; Quellbeobachtung `RV3-RES-C2-037`. [Provenienz und Header](provenance/V2-RES-020.json) · [Request](evidence/46dd92a3727011e22f780ae9ad9e71c378c57e26fd6c71904ce2d399cde69350.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":300,"Message":"The number of unique coordinates is greater than 342, which is not allowed.","Warning":null,"Mode":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 96b0826c724b532e61432034ec80051e120d997acd694a286f2135ac958396d4 |
| Request-Body | 46dd92a3727011e22f780ae9ad9e71c378c57e26fd6c71904ce2d399cde69350 |
| Request-Metadatenidentität | 5b9079eafa88985bddc68261b17f6097e9aefb354ff3743a77b55a04983b6f55 |
| Response | d699ab4b56bafe6869adc522c03989cd586a93398052361f662fed57cb563cda (127 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 6402a0ced47e1fcc557a6c1796c62c3cf4462a1d51744dad42c0c1c972bd1099 |

### V2-RES-021

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `04398ce9-9a35-4141-8407-8b0928d9fe3b`; Quellbeobachtung `RV3-RES-C2-019`. [Provenienz und Header](provenance/V2-RES-021.json) · [Request](evidence/b2173060bae91eb46167da66855ff2bee12bbd2099d973acee487863f2f7eabd.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":300,"Message":"The number of unique coordinates is greater than 342, which is not allowed.","Warning":null,"Mode":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Valid JSON accepted by the explicit empty {} schema; Code/Mode values are not required or constrained by this branch.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/200/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 9fb16b839a708df179049b08a39919e3e43298cd7bcf629853dc759b1f781638 |
| Request-Body | b2173060bae91eb46167da66855ff2bee12bbd2099d973acee487863f2f7eabd |
| Request-Metadatenidentität | 60bf0e50a7587de0f6bfc957b88822a037499486e3d29a557b9a1e7a71146a93 |
| Response | d699ab4b56bafe6869adc522c03989cd586a93398052361f662fed57cb563cda (127 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 930b44539e67c9b05f2096820c719911c78227d17afc2ff4e8d2c522cc19fa20 |

### V2-RES-022

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `1e712ebf-a513-4cef-8a96-b4d2d24495d9`; Quellbeobachtung `RV3-RES-C2-038`. [Provenienz und Header](provenance/V2-RES-022.json) · [Request](evidence/b2173060bae91eb46167da66855ff2bee12bbd2099d973acee487863f2f7eabd.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"Code":300,"Message":"The number of unique coordinates is greater than 342, which is not allowed.","Warning":null,"Mode":null}
```

- **C1 PASS:** HTTP 200 matches documented response 200.
- **C2 FAIL:** Observed application/xml does not match media alternatives of response 200.
- **C3 NOT_APPLICABLE:** Not applicable because C2 FAIL.

Schema-Pointer: `N/A`. Gesamtvorschlag: **INCONSISTENT**. Exposition: `RELATED_TO_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | 9fb16b839a708df179049b08a39919e3e43298cd7bcf629853dc759b1f781638 |
| Request-Body | b2173060bae91eb46167da66855ff2bee12bbd2099d973acee487863f2f7eabd |
| Request-Metadatenidentität | ca3b16fd9442822a187b5b2de9d70083a1bdb78f74ddcfd0db25d045624feea7 |
| Response | d699ab4b56bafe6869adc522c03989cd586a93398052361f662fed57cb563cda (127 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | 6402a0ced47e1fcc557a6c1796c62c3cf4462a1d51744dad42c0c1c972bd1099 |

### V2-RES-027

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `652bf495-80da-4e91-9f03-885a754f0e04`; Quellbeobachtung `RV3-RES-C2-039`. [Provenienz und Header](provenance/V2-RES-027.json) · [Request](evidence/e3b5baae248111e0b0d155b085a6bb55b5d205987b806f6653ec8c1ce3236ee2.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"detail":[{"type":"value_error","loc":["body","file"],"msg":"Value error, Expected UploadFile, received: <class 'str'>","input":"parent-observation-text-field-v1","ctx":{"error":{}}}]}
```

- **C1 PASS:** HTTP 422 matches documented response 422.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/422/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | e8543ec33475c34185620d32850ad02f378cfe20fcc9a08248c677d9f16d7b80 |
| Request-Body | e3b5baae248111e0b0d155b085a6bb55b5d205987b806f6653ec8c1ce3236ee2 |
| Request-Metadatenidentität | 0bd5de3af1e84b066fc5ee84a3a8b5a7809d7765f07cb898165cb2979803dc26 |
| Response | af567a6a49812b96522a62b35c676987a49a812c1415d653289513b28b89171c (185 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | dd6372258eeb2a54bf425c03cf917006a76f6aa07f053d9105dfcaced4ce4772 |

### V2-RES-028

**PENDING.**

Operation `POST /resistance/validation/file`; Ausführung `d0c656e3-a8e0-402a-a570-18cb11162a41`; Quellbeobachtung `RV3-RES-C2-041`. [Provenienz und Header](provenance/V2-RES-028.json) · [Request](evidence/e3b5baae248111e0b0d155b085a6bb55b5d205987b806f6653ec8c1ce3236ee2.bin) · [OpenAPI](contracts/084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42.json).

Exakter Response-Body (UTF-8; maßgeblich sind die verlinkten Bytes):

```json
{"detail":[{"type":"value_error","loc":["body","file"],"msg":"Value error, Expected UploadFile, received: <class 'str'>","input":"parent-observation-text-field-v1","ctx":{"error":{}}}]}
```

- **C1 PASS:** HTTP 422 matches documented response 422.
- **C2 PASS:** Observed application/json; documented media branch application/json.
- **C3 PASS:** Decoded JSON validates against the selected OpenAPI schema and its reference closure.

Schema-Pointer: `#/paths/~1resistance~1validation~1file/post/responses/422/content/application~1json/schema`. Gesamtvorschlag: **CONSISTENT**. Exposition: `DIRECTLY_EXPOSED`. DEV-/Pilot-Exaktprüfung: **0 Treffer**.

| Bindung | SHA-256 / Umfang |
| --- | --- |
| Input | e8543ec33475c34185620d32850ad02f378cfe20fcc9a08248c677d9f16d7b80 |
| Request-Body | e3b5baae248111e0b0d155b085a6bb55b5d205987b806f6653ec8c1ce3236ee2 |
| Request-Metadatenidentität | 8a4e646241121c0708f64a8816fbfe7a06a7e5adb1edff404128c7e95bafa467 |
| Response | af567a6a49812b96522a62b35c676987a49a812c1415d653289513b28b89171c (185 Bytes) |
| OpenAPI | 084b2d72929226f0984cda1ce7758c8e7d9fb1aa7e1001e308160da440828e42 |
| Gerenderter Evidenzkontext | dd6372258eeb2a54bf425c03cf917006a76f6aa07f053d9105dfcaced4ce4772 |

