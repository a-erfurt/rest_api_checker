#!/usr/bin/env python3
"""Offline descriptive RQ1–RQ3 analysis. Python 3.10+, standard library only.

Reads the pinned delivered ZIP, never a database, repository or model server.
No repairs, retries, imputed predictions, new reference labels, statistical tests,
confidence intervals, majority-vote detector, or product changes.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, io, itertools, json, re, sys, zipfile
from pathlib import Path

ZIP_HASH = '7c3951a964ec4a01c9c723e18ae3b52df329cbeb64b80b59df4985c09bebc78c'
CSV_HASH = '2922e1450a6fefba11902eebc810549a65b468138601fdce4a581a016fe51403'
MODELS = ['qwen3.6:27b','gemma3:27b','mistral-small3.2:24b']
COHERENT = {'PPP','PPF','PFN','FNN'}
CATS = ['c1','c2','c3']

def require(value, message):
    if not value: raise ValueError(message)

def sha(b): return hashlib.sha256(b).hexdigest()
def js(o): return (json.dumps(o, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)+'\n').encode('utf-8')
def ratio(a,b): return a/b if b else None

def vector_overall(v):
    if v not in COHERENT: return None
    return 'CONSISTENT' if v=='PPP' else 'INCONSISTENT'

def derive(reference, prediction):
    ro, po = vector_overall(reference), vector_overall(prediction)
    valid = prediction is not None
    app = [(a=='N') != (b=='N') for a,b in zip(reference,prediction)] if valid else [None]*3
    return dict(exact_vector_correct=valid and reference==prediction,
                coherent_prediction=(prediction in COHERENT) if valid else None,
                reference_overall=ro, predicted_overall=po,
                binary_correct=po is not None and ro==po,
                fp=(ro=='CONSISTENT' and po=='INCONSISTENT') if po else None,
                fn=(ro=='INCONSISTENT' and po=='CONSISTENT') if po else None,
                **{'applicability_error_'+c:x for c,x in zip(CATS,app)},
                applicability_error_any=any(app) if valid else None,
                applicability_error_categories=(','.join(c for c,x in zip(CATS,app) if x) or 'NONE') if valid else None,
                output_valid=valid, binary_decision_available=po is not None,
                binary_exclusion_reason=('PARSER_FAILURE' if not valid else 'INCOHERENT_VECTOR') if not po else None)

def serial(v): return '' if v is None else str(v).lower() if isinstance(v,bool) else str(v)

def metrics(rr):
    n=len(rr);v=sum(r['_valid'] for r in rr); k=sum(r['_correct'] for r in rr)
    b=sum(r['_overall'] is not None for r in rr)
    confusion = collections.Counter(r['_confusion'] for r in rr if r['_confusion'])
    tp,tn,fp,fn=(confusion[t] for t in ('TP','TN','FP','FN'))
    return dict(planned=n, valid=v, parser_failure=sum(r['run_result']=='parser_failure' for r in rr),
                technical_failure=sum(r['run_result']=='technical_failure' for r in rr),
                valid_incorrect=v-k, exact_correct=k, exact_planned=ratio(k,n), exact_valid=ratio(k,v),
                valid_coverage=ratio(v,n), binary_available=b, binary_coverage=ratio(b,n),
                incoherent=sum(r['_valid'] and r['_overall'] is None for r in rr),
                binary_correct=tp+tn,binary_planned=ratio(tp+tn,n),binary_conditional=ratio(tp+tn,b),
                tp=tp,tn=tn,fp=fp,fn=fn, precision=ratio(tp,tp+fp), recall_conditional=ratio(tp,tp+fn),
                f1_conditional=ratio(2*tp,2*tp+fp+fn),
                reference_positive=sum(r['reference_vector']!='PPP' for r in rr),
                available_positive=tp+fn, positive_coverage=ratio(tp+fn,sum(r['reference_vector']!='PPP' for r in rr)),
                tp_over_all_reference_positive=ratio(tp,sum(r['reference_vector']!='PPP' for r in rr)),
                runs_with_applicability_error=sum(any(r['_app']) for r in rr if r['_valid']))

def write_csv(path, rr):
    require(bool(rr),'Empty output table: '+str(path))
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]),lineterminator='\n')
        w.writeheader()
        for row in rr:
            w.writerow({k:serial(v) if not isinstance(v,(list,dict)) else json.dumps(v,ensure_ascii=False,sort_keys=True) for k,v in row.items()})

def analyze(input_zip: Path, output: Path, review: Path | None):
    raw=input_zip.read_bytes(); require(sha(raw)==ZIP_HASH,'Unexpected source ZIP')
    source_before=sha(raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        source={n.removeprefix('analysis_10003/'):z.read(n) for n in z.namelist()}
    verified_hashes=0
    for checksum in ['SHA256SUMS','DELIVERY_SHA256SUMS']:
        for line in source[checksum].decode().splitlines():
            h,p=line.split('  ',1);require(sha(source[p])==h,'Hash mismatch: '+p); verified_hashes+=1
    require(sha(source['analysis_10003.csv'])==CSV_HASH,'Wrong CSV')
    data=json.loads(source['sources/dataset.json']);cases={c['candidate_id']:c for c in data['cases']}
    dictionary=json.loads(source['column_dictionary.json'])
    with zipfile.ZipFile(io.BytesIO(source['sources/experiment_10003_verification.zip'])) as z:
        nested={n.removeprefix('verification_10003/'):z.read(n) for n in z.namelist()}
    for line in nested['SHA256SUMS'].decode().splitlines():
        h,p=line.split('  ',1);require(sha(nested[p])==h,'Nested hash mismatch: '+p);verified_hashes+=1
    snapshot=json.loads(nested['evidence/scoped_snapshot.json']);setup=json.loads(nested['evidence/setup.json'])
    audit=json.loads(nested['evidence/verification.json'])
    rr=list(csv.DictReader(io.StringIO(source['analysis_10003.csv'].decode())))
    require(len(rr)==len({r['run_id'] for r in rr})==738,'Not 738 unique runs')
    require(len(cases)==82,'Not 82 cases')
    require({(r['case_id'],r['model'],int(r['repetition'])) for r in rr}==set(itertools.product(cases,MODELS,[1,2,3])),'Factorial mismatch')
    runs={r['id']:r for r in snapshot['runs']};pred={r['run_id']:r for r in snapshot['predictions']}
    attempts={r['run_id']:r for r in snapshot['attempts']}; ev={r['run_id']:r for r in snapshot['run_evidence']}
    dc={r['id']:r for r in snapshot['bindings']['dataset_cases']}; ref={r['id']:r for r in snapshot['bindings']['reference_results']}
    mods={r['id']:r for r in snapshot['bindings']['models']}; cfg={r['id']:r for r in snapshot['bindings']['run_configs']}
    require(len(runs)==len(attempts)==738 and len(pred)==734,'Snapshot cardinality mismatch')
    require(snapshot['experiment']['id']==10003 and snapshot['experiment']['dataset_id']==3,'Wrong experiment')
    for r in rr:
        rid=int(r['run_id']);run=runs[rid];d=dc[run['dataset_case_id']];reference=ref[d['reference_id']];c=cases[r['case_id']]
        require(r['case_id']==d['case_code'] and r['model']==mods[run['model_id']]['name'],'Source join mismatch')
        require(int(r['experiment_id'])==run['experiment_id']==10003 and int(r['dataset_id'])==d['dataset_id']==3,'Scope mismatch')
        require(int(r['reference_id'])==d['reference_id'] and reference['case_id']==d['case_id'],'Reference binding mismatch')
        require(int(r['prompt_id'])==run['prompt_id']==2 and int(r['run_config_id'])==run['run_config_id'] in cfg,'Prompt/config mismatch')
        require(int(r['seed'])==run['seed']=={1:101,2:202,3:303}[int(r['repetition'])],'Seed mismatch')
        require(c['reference_status']=='HUMAN_CONFIRMED_REFERENCE' and c['manual_review_status']=='APPROVED','Unconfirmed reference')
        require(r['reference_vector']==''.join(reference[k][0] for k in CATS)==''.join(c[k.upper()][0] for k in CATS),'Reference changed')
        require(r['family']==c['dependency_family'] and r['api']==c['api'] and r['case_characteristic']==c['natural_vs_controlled'],'Metadata changed')
        require(int(r['attempt_number'])==attempts[rid]['attempt']==1 and r['run_result']==run['result']==attempts[rid]['result'],'Attempt changed')
        require(r['parser_status']==ev[rid]['parser']['status'] and r['parser_diagnostic']==ev[rid]['parser']['code'],'Parser mismatch')
        p=pred.get(rid)
        pv=''.join(p[k][0] for k in CATS) if p else None
        require((r['predicted_vector'] or None)==pv,'Prediction changed')
        for k in CATS:
            require(r['predicted_'+k]==(p[k] if p else ''),'Prediction dimension mismatch')
        derived=derive(r['reference_vector'],pv)
        for k,v in derived.items(): require(r[k]==serial(v),'Derived field mismatch: '+k+' run '+str(rid))
        r['_valid']=p is not None;r['_correct']=derived['exact_vector_correct'];r['_overall']=derived['predicted_overall']
        r['_app']=[derived['applicability_error_'+k] for k in CATS]
        r['_confusion']=None
        if r['_overall']:
            if r['reference_vector']=='PPP': r['_confusion']='TN' if r['_overall']=='CONSISTENT' else 'FP'
            else: r['_confusion']='TP' if r['_overall']=='INCONSISTENT' else 'FN'
    require(collections.Counter(r['run_result'] for r in rr)=={'valid':734,'parser_failure':4},'Outcome mismatch')
    require(collections.Counter(''.join(c[k][0] for k in ('C1','C2','C3')) for c in cases.values())=={'PPP':29,'PPF':10,'PFN':29,'FNN':14},'Class composition mismatch')
    require(collections.Counter(c['api'] for c in cases.values())=={'EDX':52,'Resistance':30},'API composition mismatch')
    require({int(r['run_id']) for r in rr if not r['_valid']}=={11078,11080,11096,11098},'Parser failure identity mismatch')

    # Independent finite-state checks, not experiment observations.
    tests=0
    for rv in COHERENT:
        for pv in [''.join(v) for v in itertools.product('PFN',repeat=3)]+[None]:
            d=derive(rv,pv)
            expected=(pv is not None and ((pv[0]=='F' and pv[1:]=='NN') or (pv[0]=='P' and ((pv[1]=='F' and pv[2]=='N') or (pv[1]=='P' and pv[2] in 'PF')))))
            require(d['binary_decision_available']==expected,'Coherence test')
            if not expected: require(d['predicted_overall'] is None and d['fp'] is None and d['fn'] is None,'Missing binary test')
            tests+=1

    require(not output.exists(),'Refusing to overwrite output directory')
    output.mkdir(parents=True)
    tables=output/'tables';tables.mkdir()
    model_rows=[dict(model=m,**metrics([r for r in rr if r['model']==m])) for m in MODELS]
    write_csv(tables/'rq1_models.csv',model_rows)
    group_rows=[]
    grouping=['api','reference_vector','case_characteristic','service_state','family','input_family','response_pattern_group']
    for key in grouping:
        for value in sorted({r[key] for r in rr}):
            for m in MODELS:
                sub=[r for r in rr if r[key]==value and r['model']==m]
                group_rows.append(dict(grouping=key,group=value,model=m,cases=len({r['case_id'] for r in sub}),**metrics(sub)))
    write_csv(tables/'rq2_subgroups.csv',group_rows)
    category_rows=[]; confusion_rows=[]
    for m in MODELS:
        mr=[r for r in rr if r['model']==m]
        for cat in CATS:
            valid=[r for r in mr if r['_valid']]
            appl=[r for r in mr if r['reference_'+cat]!='NOT_APPLICABLE']
            applvalid=[r for r in appl if r['_valid']]
            correct=sum(r['reference_'+cat]==r['predicted_'+cat] for r in valid)
            appcorrect=sum(r['reference_'+cat]==r['predicted_'+cat] for r in applvalid)
            value=dict(model=m,category=cat.upper(),planned=len(mr),valid=len(valid),correct=correct,
                       correctness_planned=ratio(correct,len(mr)),correctness_valid=ratio(correct,len(valid)),
                       applicable_planned=len(appl),applicable_valid=len(applvalid),applicable_correct=appcorrect,
                       applicable_correctness_planned=ratio(appcorrect,len(appl)),applicable_correctness_valid=ratio(appcorrect,len(applvalid)),
                       category_fp=sum(r['reference_'+cat]=='PASS' and r['predicted_'+cat]=='FAIL' for r in valid),
                       category_fn=sum(r['reference_'+cat]=='FAIL' and r['predicted_'+cat]=='PASS' for r in valid),
                       false_applicable=sum(r['reference_'+cat]=='NOT_APPLICABLE' and r['predicted_'+cat]!='NOT_APPLICABLE' for r in valid),
                       false_not_applicable=sum(r['reference_'+cat]!='NOT_APPLICABLE' and r['predicted_'+cat]=='NOT_APPLICABLE' for r in valid))
            require(value['correct']+value['category_fp']+value['category_fn']+value['false_applicable']+value['false_not_applicable']==value['valid'],'Dimension partition')
            category_rows.append(value)
            cc=collections.Counter((r['reference_'+cat],r['predicted_'+cat] or 'NO_PREDICTION') for r in mr)
            for (rv,pv),n in sorted(cc.items()): confusion_rows.append(dict(model=m,category=cat.upper(),reference=rv,prediction=pv,count=n))
    write_csv(tables/'rq2_categories.csv',category_rows);write_csv(tables/'rq2_category_confusion.csv',confusion_rows)
    vconf=[]
    for m in MODELS:
        cc=collections.Counter((r['reference_vector'],r['predicted_vector'] or 'NO_PREDICTION') for r in rr if r['model']==m)
        for (rv,pv),n in sorted(cc.items()):vconf.append(dict(model=m,reference=rv,prediction=pv,count=n))
    write_csv(tables/'vector_confusion.csv',vconf)
    rep_rows=[dict(model=m,repetition=rep,seed={1:101,2:202,3:303}[rep],**metrics([r for r in rr if r['model']==m and int(r['repetition'])==rep])) for m in MODELS for rep in [1,2,3]]
    write_csv(tables/'rq3_repetitions.csv',rep_rows)
    triples=[]
    for cid in cases:
        for m in MODELS:
            g=sorted([r for r in rr if r['case_id']==cid and r['model']==m],key=lambda r:int(r['repetition']))
            valid=sum(r['_valid'] for r in g);full=valid==3;unique=len({r['predicted_vector'] for r in g if r['_valid']})
            correct=sum(r['_correct'] for r in g); stable=full and unique==1
            kind='INCOMPLETE_OUTPUT' if not full else 'STABLE_CORRECT' if correct==3 else 'STABLE_WRONG' if stable else 'VARIABLE'
            binaryfull=all(r['_overall'] is not None for r in g)
            triples.append(dict(case_id=cid,api=cases[cid]['api'],family=cases[cid]['dependency_family'],model=m,
                                reference_vector=g[0]['reference_vector'],r1=g[0]['predicted_vector'] or 'PARSER_FAILURE',r2=g[1]['predicted_vector'] or 'PARSER_FAILURE',r3=g[2]['predicted_vector'] or 'PARSER_FAILURE',
                                valid_repetitions=valid,correct_repetitions=correct,full_valid_triple=full,
                                distinct_valid_vectors=unique,stable_vector=(stable if full else None),all_three_correct=correct==3,
                                result_type=kind,full_binary_triple=binaryfull,
                                binary_stable=(len({r['_overall'] for r in g})==1 if binaryfull else None)))
    write_csv(tables/'rq3_case_model_triples.csv',triples)
    stability=[]
    for m in MODELS:
        ts=[t for t in triples if t['model']==m];ct=collections.Counter(t['result_type'] for t in ts)
        full=sum(t['full_valid_triple'] for t in ts);stable=sum(t['stable_vector'] is True for t in ts)
        stability.append(dict(model=m,cases=len(ts),complete_valid_triples=full,triple_coverage=ratio(full,len(ts)),
                              identical_triples=stable,identical_given_complete=ratio(stable,full),all_three_correct=ct['STABLE_CORRECT'],
                              all_three_correct_rate=ratio(ct['STABLE_CORRECT'],len(ts)),stable_wrong=ct['STABLE_WRONG'],variable=ct['VARIABLE'],
                              two_plus_one=sum(t['full_valid_triple'] and t['distinct_valid_vectors']==2 for t in ts),
                              three_different=sum(t['full_valid_triple'] and t['distinct_valid_vectors']==3 for t in ts),
                              incomplete=ct['INCOMPLETE_OUTPUT'],complete_binary_triples=sum(t['full_binary_triple'] for t in ts),
                              identical_binary_triples=sum(t['binary_stable'] is True for t in ts)))
    write_csv(tables/'rq3_stability.csv',stability)
    lookup={(r['case_id'],r['model'],int(r['repetition'])):r for r in rr}
    pairs=[];excluded=[]
    for cid,c in cases.items():
        oid=c['paired_original_final_candidate_id']
        if oid==cid:continue
        if oid not in cases:
            excluded.append(dict(case_id=cid,paired_original=oid,paired_original_membership=c['paired_original_membership'],reason='No original prediction in Main; provenance only'))
            continue
        typ=c['natural_vs_controlled']
        group=c['api']+':'+ ('REQUEST_VALIDATION_CONTROL' if typ=='REQUEST_VALIDATION_CONTROL' else c['service_state'])
        for m in MODELS:
            for rep in [1,2,3]:
                a,b=lookup[oid,m,rep],lookup[cid,m,rep]
                both=a['_valid'] and b['_valid']
                pairs.append(dict(api=c['api'],group=group,original=oid,variant=cid,family=c['dependency_family'],model=m,repetition=rep,
                                  reference_original=a['reference_vector'],reference_variant=b['reference_vector'],
                                  prediction_original=a['predicted_vector'],prediction_variant=b['predicted_vector'],
                                  reference_changes=a['reference_vector']!=b['reference_vector'],both_valid=both,
                                  both_correct=a['_correct'] and b['_correct'],original_correct=a['_correct'],variant_correct=b['_correct'],
                                  identical_predictions=(a['predicted_vector']==b['predicted_vector'] if both else None)))
    require(len(excluded)==21 and len(pairs)==39*9,'Pair membership mismatch')
    write_csv(tables/'rq2_pairs.csv',pairs);write_csv(tables/'provenance_only_excluded_pairs.csv',excluded)
    pair_summary=[]
    for group in sorted({p['group'] for p in pairs}):
        for m in MODELS:
            ps=[p for p in pairs if p['group']==group and p['model']==m]
            pair_summary.append(dict(group=group,model=m,pairs=len(ps)//3,paired_repetitions=len(ps),both_valid=sum(p['both_valid'] for p in ps),
                                     both_correct=sum(p['both_correct'] for p in ps),both_correct_rate=ratio(sum(p['both_correct'] for p in ps),len(ps)),
                                     identical_predictions=sum(p['identical_predictions'] is True for p in ps)))
    write_csv(tables/'rq2_pair_summary.csv',pair_summary)
    errors=[]
    for r in rr:
        if r['_correct']:continue
        p=pred.get(int(r['run_id']))
        errors.append(dict(run_id=int(r['run_id']),case_id=r['case_id'],model=r['model'],repetition=int(r['repetition']),seed=int(r['seed']),
                           reference=r['reference_vector'],prediction=r['predicted_vector'],parser_status=r['parser_status'],
                           semantic_confusion=r['_confusion'],applicability_error_categories=r['applicability_error_categories'],
                           **{k+'_reason':p[k+'_reason'] if p else None for k in CATS}))
    write_csv(tables/'error_inventory.csv',errors)
    (output/'all_stored_predictions.json').write_bytes(js(snapshot['predictions']))
    (output/'parser_failures.json').write_bytes(js(audit['parser_failures']))
    bodymap={}
    if review:
        text=review.read_text()
        for block in re.split(r'(?m)^### ',text)[1:]:
            cid=block.splitlines()[0].strip(); match=re.search(r'```json\n(.*?)\n```',block,re.S)
            if cid in cases and match:
                body=match.group(1);require(sha(body.encode())==cases[cid]['body_sha256'],'Body mismatch: '+cid)
                bodymap[cid]=dict(body=body,sha256=sha(body.encode()),source='case_review_details.md: code block; labels not imported')
        require(len(bodymap)==82,'Missing body in review supplement')
        (output/'response_bodies_hash_verified.json').write_bytes(js(bodymap))
        (output/'case_review_details_source.md').write_bytes(review.read_bytes())
    selected=[10433,10454,10457,10436,10439,10565,10566,10567,10574,10575,10576,10568,11069,11138]
    qualitative=[]
    rows_byid={int(r['run_id']):r for r in rr}
    for rid in selected:
        r=rows_byid[rid];c=cases[r['case_id']]
        qualitative.append(dict(run_id=rid,case_id=r['case_id'],model=r['model'],seed=int(r['seed']),reference_vector=r['reference_vector'],prediction=pred[rid],
                                response=bodymap.get(r['case_id']),reference_reasons=c['proposal_reasons'],reference_status=c['reference_status'],
                                schema_pointer=c['schema_pointer'],contract_sha256=c['contract_sha256'],body_sha256=c['body_sha256'],
                                response_status=c['http_status'],response_content_type=c['content_type']))
    (output/'qualitative_examples.json').write_bytes(js(qualitative))
    result=dict(experiment_id=10003,source_zip_sha256=ZIP_HASH,source_csv_sha256=CSV_HASH,
                dataset=dict(cases=82,api_counts={'EDX':52,'Resistance':30},reference_counts={'PPP':29,'PPF':10,'PFN':29,'FNN':14},
                             families=len({c['dependency_family'] for c in cases.values()}),exact_contexts=len({c['exact_model_context_sha256'] for c in cases.values()}),
                             response_pattern_groups=len({c['response_pattern_group'] for c in cases.values()}),
                             scientific_ancestry_values=sorted({c['independent_scientific_ancestry'] for c in cases.values()})),
                models=model_rows,categories=category_rows,stability=stability,repetitions=rep_rows,pair_summary=pair_summary,
                selected_subgroups=[g for g in group_rows if g['grouping'] in ['api','reference_vector','case_characteristic','service_state']],
                interpretation_policy=dict(primary='Exact vector correctness over planned runs; available-output result and coverage separately.',
                                           binary='Only coherent valid vectors; precision/recall/F1 conditional on available binary decisions.',
                                           applicability='Reference-based; false applicability and false non-applicability distinct from P/F errors.',
                                           stability='Complete valid triples; 3/3 correct over all 82 cases; incomplete groups separate.',
                                           pairs='Descriptive supplementary analysis of 39 stored in-Main original/variant links, same model and repetition; excluded originals not scored.',
                                           inference='No p-values, confidence intervals, independence assumptions, causal attribution, or population-level performance estimates.',
                                           qualitative='Post-result purposive selection; no quantitative explanation score; final reference documentation plus hash-verified bodies when supplied.',
                                           selection_history='No new pre-registration claimed; primary definitions retained; detailed pair presentation and example selection performed after outcomes were available.'))
    (output/'results.json').write_bytes(js(result))
    verification=dict(status='PASS',delivered_hash_checks=verified_hashes,independently_checked_rows=738,exhaustive_derived_cases=tests,
                      counts=dict(logical_runs=738,attempts=738,predictions=734,parser_failure=4,technical_failure=0),
                      csv_reproduction_sha256=CSV_HASH,source_input_unchanged=source_before==sha(input_zip.read_bytes()),
                      supplementary_response_bodies_matched=len(bodymap),
                      limits=['Database not reopened; original 6238-payload audit is an archived source claim, not a new live audit here.',
                              'Raw OpenAPI documents and all valid provider response bytes are not in this delivery; qualitative schema comparisons use the final documented reference decisions.',
                              'The supplied independent verifier additionally checks original /Users/aerfurt paths and cannot complete those local checks here. CSV regeneration succeeded without those paths.'])
    (output/'analysis_verification.json').write_bytes(js(verification))
    (output/'evaluate_rqs.py').write_bytes(Path(__file__).read_bytes())
    (output/'README.md').write_text('''# Experiment 10003 – deskriptive Auswertung\n\n## Reproduktion\n\nPython 3.10 oder neuer, nur Standardbibliothek. Das unveränderte Eingabe-ZIP stammt aus dem gelieferten Offline-Export.\n\n```bash\npython3 evaluate_rqs.py --input-zip /path/experiment_10003_offline_analysis.zip --output /path/NEW_RESULTS --review-details /path/case_review_details.md\n```\n\n`--review-details` ist optional und wird ausschließlich für hashgleiche Response-Body-Texte verwendet, niemals zur Übernahme alter Referenzvorschläge. Ohne diese Datei bleiben sämtliche quantitativen Ergebnisse identisch.\n\nAlle CSV-Dateien unter `tables/` und `results.json` werden deterministisch aus den Quellen erzeugt. `qualitative_examples.json` enthält eine nach Ergebnissichtung ausgewählte, nicht repräsentative Beispielsammlung. Ein fehlendes binäres Urteil ist keine False-Negative-Klassifikation. Die Auswertung verändert keine Originaldaten und kontaktiert keine Dienste.\n\nDie finalen Referenzen werden aus dem verifizierten Snapshot gelesen und mit `sources/dataset.json` abgeglichen. Im Paket fehlen vollständige OpenAPI-Rohdokumente; es erfolgt keine erneute Referenzvalidierung. Die Dateien aus der ersten manuellen Review dienen nur nach Hashabgleich zur Anzeige der Response-Bytes.\n\nDie deutschsprachige Ergebnisdarstellung und die Excel-Arbeitsmappe sind zusätzliche Darstellungen dieser Auswertung; `evaluate_rqs.py` erzeugt die maschinenlesbaren Ergebnistabellen.\n''',encoding='utf-8')
    (output/'source_manifest.json').write_bytes(source['manifest.json'])
    (output/'column_dictionary_source.json').write_bytes(source['column_dictionary.json'])
    for m in model_rows:
        require(m['exact_correct']+m['valid_incorrect']+m['parser_failure']+m['technical_failure']==m['planned'],'Outcome partition')
        require(m['tp']+m['tn']+m['fp']+m['fn']==m['binary_available'],'Binary partition')
    print(json.dumps({'status':'PASS','output':str(output),'models':model_rows,'stability':stability},ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-zip',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--review-details',type=Path)
    args=ap.parse_args();analyze(args.input_zip,args.output,args.review_details)
