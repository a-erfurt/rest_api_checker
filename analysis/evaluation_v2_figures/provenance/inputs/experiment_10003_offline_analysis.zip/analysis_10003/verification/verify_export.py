"""Independent source-to-CSV verification; never accesses a database or service."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import itertools
import json
from pathlib import Path
import zipfile


def check(condition, message):
    if not condition:
        raise ValueError(message)


def h(path):
    return sha256(path.read_bytes()).hexdigest()


def expected_coherence(v):
    if v[0] == 'FAIL':
        return v[1] == v[2] == 'NOT_APPLICABLE'
    if v[0] != 'PASS':
        return False
    if v[1] == 'FAIL':
        return v[2] == 'NOT_APPLICABLE'
    return v[1] == 'PASS' and v[2] in ('PASS', 'FAIL')


def text(value):
    return '' if value is None else str(value).lower() if isinstance(value, bool) else str(value)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--export', type=Path, required=True)
    ap.add_argument('--reproduction', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    base = args.export
    for line in (base / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        check(h(base / name) == expected, 'Package hash mismatch: ' + name)
    manifest = json.loads((base / 'manifest.json').read_text())
    for entry in manifest['files']:
        p = base / entry['path']
        check(h(p) == entry['sha256'] and p.stat().st_size == entry['size_bytes'], 'Manifest mismatch')
    check(h(base / 'analysis_10003.csv') == manifest['export']['sha256'], 'CSV identity mismatch')
    check(h(base / 'build_export.py') == manifest['script']['sha256'], 'Builder identity mismatch')
    with zipfile.ZipFile(base / 'sources/experiment_10003_verification.zip') as z:
        s = json.loads(z.read('verification_10003/evidence/scoped_snapshot.json'))
        setup = json.loads(z.read('verification_10003/evidence/setup.json'))
    data = json.loads((base / 'sources/dataset.json').read_text())
    cases = {c['candidate_id']: c for c in data['cases']}
    dc = {c['id']: c for c in s['bindings']['dataset_cases']}
    refs = {r['id']: r for r in s['bindings']['reference_results']}
    models = {m['id']: m for m in s['bindings']['models']}
    runs = {r['id']: r for r in s['runs']}
    attempts = {r['run_id']: r for r in s['attempts']}
    predictions = {r['run_id']: r for r in s['predictions']}
    evidence = {r['run_id']: r for r in s['run_evidence']}
    with (base / 'analysis_10003.csv').open(newline='') as f:
        rows = list(csv.DictReader(f))
    check(len(rows) == len({r['run_id'] for r in rows}) == 738, 'Row/run uniqueness')
    check({int(r['run_id']) for r in rows} == set(runs), 'Run set')
    expected_slots = set(itertools.product(cases, [m['name'] for m in models.values()], [1, 2, 3]))
    check({(r['case_id'], r['model'], int(r['repetition'])) for r in rows} == expected_slots, 'Factorial slots')
    check(Counter(r['parser_status'] for r in rows) == {'VALID_OUTPUT': 734, 'PARSER_FAILURE': 4}, 'Final counts')
    check(Counter(''.join(c[k][0] for k in ('C1', 'C2', 'C3')) for c in cases.values()) ==
          {'PPP': 29, 'PPF': 10, 'PFN': 29, 'FNN': 14}, 'Case reference distribution')
    check(Counter(c['api'] for c in cases.values()) == {'EDX': 52, 'Resistance': 30}, 'Case API counts')
    for number, row in enumerate(rows, 1):
        run_id = int(row['run_id'])
        run, a, e = runs[run_id], attempts[run_id], evidence[run_id]
        case_binding = dc[run['dataset_case_id']]
        c, reference = cases[case_binding['case_code']], refs[case_binding['reference_id']]
        pred = predictions.get(run_id)
        check(int(row['run_order']) == run['run_order'] == number, 'Order changed')
        check(row['case_id'] == case_binding['case_code'], 'Case join')
        check(row['api'] == c['api'] and row['family'] == c['dependency_family'], 'Metadata join')
        check(row['case_characteristic'] == c['natural_vs_controlled'], 'Characteristic changed')
        check(row['model'] == models[run['model_id']]['name'], 'Model changed')
        check(int(row['seed']) == {1: 101, 2: 202, 3: 303}[int(row['repetition'])] == run['seed'], 'Seed mismatch')
        check(row['parser_status'] == e['parser']['status'] and row['parser_diagnostic'] == e['parser']['code'], 'Parser changed')
        check(row['request_sha256'] == e['request_sha256'] and row['response_sha256'] == e['response_sha256'], 'Response/request identity')
        check(int(row['attempt_id']) == a['id'] and row['attempt_number'] == '1', 'Attempt mismatch')
        rv = tuple(reference[k] for k in ('c1', 'c2', 'c3'))
        pv = tuple(pred[k] for k in ('c1', 'c2', 'c3')) if pred else None
        for i, k in enumerate(('c1', 'c2', 'c3')):
            check(row['reference_' + k] == rv[i] == c[k.upper()], 'Reference changed')
            check(row['predicted_' + k] == (pv[i] if pv else ''), 'Prediction changed/repaired')
            expected = ((rv[i] == 'NOT_APPLICABLE') != (pv[i] == 'NOT_APPLICABLE')) if pv else None
            check(row['applicability_error_' + k] == text(expected), 'Applicability mismatch')
        check(row['exact_vector_correct'] == text(pv is not None and rv == pv), 'Exact-vector flag')
        coherence = expected_coherence(pv) if pv else None
        check(row['coherent_prediction'] == text(coherence), 'Coherence flag')
        reference_overall = 'INCONSISTENT' if 'FAIL' in rv else 'CONSISTENT'
        predicted_overall = ('INCONSISTENT' if 'FAIL' in pv else 'CONSISTENT') if coherence else ''
        check(row['reference_overall'] == reference_overall and row['predicted_overall'] == predicted_overall, 'Overall derivation')
        check(row['binary_correct'] == text(bool(predicted_overall) and predicted_overall == reference_overall), 'Binary flag')
        for key, condition in [('fp', reference_overall == 'CONSISTENT' and predicted_overall == 'INCONSISTENT'),
                               ('fn', reference_overall == 'INCONSISTENT' and predicted_overall == 'CONSISTENT')]:
            check(row[key] == text(condition if predicted_overall else None), 'Semantic confusion flag')
        if pred is None:
            check(row['prediction_id'] == row['predicted_vector'] == row['applicability_error_any'] == row['applicability_error_categories'] == '', 'Imputed failure')
    # Exhaustive truth-table check of the consequential derivation helper, including
    # cases absent from these observations. Expected coherence is independently gated.
    spec = importlib.util.spec_from_file_location('offline_builder', base / 'build_export.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    all_vectors = list(itertools.product(('PASS', 'FAIL', 'NOT_APPLICABLE'), repeat=3))
    coherent_refs = [v for v in all_vectors if expected_coherence(v)]
    check(len(coherent_refs) == 4, 'Coherent truth table')
    checked = 0
    for reference, prediction in itertools.product(coherent_refs, all_vectors + [None]):
        d = module.derive(reference, prediction)
        valid = prediction is not None
        coherent = expected_coherence(prediction) if valid else None
        check(d['coherent_prediction'] == coherent, 'Truth-table coherence')
        check(d['exact_vector_correct'] == (valid and reference == prediction), 'Truth-table correctness')
        available = valid and coherent
        check(d['binary_decision_available'] == bool(available), 'Truth-table binary availability')
        if not available:
            check(d['predicted_overall'] is d['fp'] is d['fn'] is None and d['binary_correct'] is False, 'Truth-table null behavior')
        for i, k in enumerate(('c1', 'c2', 'c3')):
            expected = ((reference[i] == 'NOT_APPLICABLE') != (prediction[i] == 'NOT_APPLICABLE')) if valid else None
            check(d['applicability_error_' + k] == expected, 'Truth-table applicability')
        checked += 1
    check((args.reproduction / 'analysis_10003.csv').read_bytes() == (base / 'analysis_10003.csv').read_bytes(), 'Non-reproducible CSV')
    check((args.reproduction / 'column_dictionary.json').read_bytes() == (base / 'column_dictionary.json').read_bytes(), 'Non-reproducible definitions')
    check((args.reproduction / 'integrity.json').read_bytes() == (base / 'integrity.json').read_bytes(), 'Non-reproducible integrity checks')
    original_checks = []
    provenance = json.loads((base / 'sources/source_provenance.json').read_text())
    for source in provenance['sources']:
        original = Path(source['original_path'])
        check(h(original) == source['sha256'], 'Original source changed: ' + str(original))
        original_checks.append({'path': str(original), 'sha256': source['sha256'], 'unchanged': True})
    result = dict(status='PASS', verified_at_utc=datetime.now(timezone.utc).isoformat(),
                  verifier_sha256=h(Path(__file__)), csv_sha256=h(base / 'analysis_10003.csv'),
                  snapshot_sha256=manifest['source_snapshot']['sha256'], rows_independently_checked=738,
                  exhaustive_derivation_cases=checked, factorial_design='82 cases x 3 models x 3 repetitions',
                  outcomes={'valid': 734, 'parser_failure': 4, 'technical_failure': 0},
                  reference_distribution_cases={'PPP': 29, 'PPF': 10, 'PFN': 29, 'FNN': 14},
                  api_distribution_cases={'EDX': 52, 'Resistance': 30},
                  csv_reproduction_byte_identical=True, source_preservation=original_checks,
                  database_connections=0, model_calls=0, product_imports=0,
                  note='Original source hash checks require their recorded local paths. Reproduction of CSV itself uses bundled files only.')
    with args.output.open('x') as f:
        json.dump(result, f, ensure_ascii=False, sort_keys=True, indent=2)
        f.write('\n')
    print(json.dumps({'status': 'PASS', 'rows': 738, 'truth_table_cases': checked,
                      'csv_reproduction_byte_identical': True, 'csv_sha256': result['csv_sha256']}))


if __name__ == '__main__':
    main()
