Experiment 10003: frozen offline analysis table for RQ1-RQ3

738 data records plus one header. The only observations/predictions are the original saved snapshot.
Source ZIP is preserved byte-for-byte. Dataset/freeze/P2 source copies match its archived identities.
Read column_dictionary.json before aggregating. Empty fields are unavailable, not NOT_APPLICABLE.
case_characteristic copies natural_vs_controlled; family copies dependency_family without reinterpretation.
No overall label or semantic FP/FN is assigned to a parser failure or incoherent vector.
Failures have exact_vector_correct=false and binary_correct=false for failure-aware counting.
coherent_prediction and applicability errors are null for absent predictions.
The four CATEGORY_FIELDS failures are final, unrepaired records.

Reproduce using Python 3.9+ standard library, no repository/environment/credentials/services needed:
  python3 build_export.py --output /absolute/path/to/NEW_DIRECTORY
Run the script from this package; output must not exist. Original inputs are never overwritten.
The new analysis_10003.csv must have the same SHA-256 as manifest.json export.sha256.
Manifest generation timestamps/runtime details change on reproduction; CSV bytes do not.
SHA256SUMS covers every package file except itself. manifest.json covers all files except itself and SHA256SUMS.
This is an offline analysis dataset, not a stored DB evaluation report or a performance interpretation.
