"""Experiment 10003: deterministic offline export. Python standard library only.

Reads bundled, hash-pinned source bytes. No product imports, database, network,
parser reruns, output repair, model calls or aggregate performance metrics.
Run: python3 build_export.py --output /absolute/path/to/NEW_DIRECTORY
"""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import sys
import zipfile
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
PINNED = {
    'experiment_10003_verification.zip': '1140af218f5ebf5ac404ed67391709eb74dcc89e7a874a29647cbdc7df2f7895',
    'dataset.json': '2c831cc727cc3fd841139f6f877dc2fa725ffedecf3ee96138f705245833f44f',
    'freeze.json': '3e477b77adc7d6494d5fb4b967dd849bb4ec7113f1091aa24ca5b1189a38c8a3',
    'p2_structured_checklist_v1.txt': '50bfce7831530c7d63dd469ed82fb9acab755bedf4808ae5574775fc5505594f',
}
CATS = ('c1', 'c2', 'c3')
P, F, N = 'PASS', 'FAIL', 'NOT_APPLICABLE'
COHERENT = {(P, P, P), (P, P, F), (P, F, N), (F, N, N)}
FAILURES = {11078: ('V2-RES-020', 1, 101), 11080: ('V2-RES-020', 3, 303),
            11096: ('V2-RES-022', 1, 101), 11098: ('V2-RES-022', 3, 303)}
MODELS = {'qwen3.6:27b', 'gemma3:27b', 'mistral-small3.2:24b'}
FIELDS = ('run_id case_id api family case_characteristic model repetition seed '
          'reference_c1 reference_c2 reference_c3 parser_status parser_diagnostic '
          'predicted_c1 predicted_c2 predicted_c3 exact_vector_correct coherent_prediction '
          'reference_overall predicted_overall binary_correct fp fn '
          'applicability_error_c1 applicability_error_c2 applicability_error_c3 '
          'applicability_error_any applicability_error_categories '
          'output_valid binary_decision_available binary_exclusion_reason '
          'reference_vector predicted_vector run_result '
          'service_state execution_origin input_family input_format observed_mode business_code '
          'paired_original_final_candidate_id paired_original_membership input_lineage_id '
          'response_pattern_group exact_model_context_sha256 independent_scientific_ancestry '
          'experiment_id dataset_id run_order case_position dataset_case_id case_record_id '
          'reference_id family_record_id model_id model_digest model_template_sha256 prompt_id '
          'run_config_id attempt_id attempt_number prediction_id request_file_id response_file_id '
          'diagnostics_file_id request_sha256 response_sha256 diagnostics_sha256 '
          'recovery_spool_sha256 reference_source_file_id reference_source_pointer '
          'case_metadata_pointer').split()
BOOLS = set(('exact_vector_correct coherent_prediction binary_correct fp fn '
             'applicability_error_c1 applicability_error_c2 applicability_error_c3 '
             'applicability_error_any output_valid binary_decision_available').split())
INTS = set(('run_id repetition seed business_code experiment_id dataset_id run_order '
            'case_position dataset_case_id case_record_id reference_id family_record_id '
            'model_id prompt_id run_config_id attempt_id attempt_number prediction_id '
            'request_file_id response_file_id diagnostics_file_id reference_source_file_id').split())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode()


def pretty(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True,
                       indent=2, allow_nan=False) + '\n').encode()


def index(rows, key='id'):
    result = {r[key]: r for r in rows}
    require(len(result) == len(rows), 'Duplicate join key: ' + key)
    return result


def code(vector):
    return ''.join(x[0] for x in vector)


def overall(vector):
    return ('CONSISTENT' if vector == (P, P, P) else 'INCONSISTENT') if vector in COHERENT else None


def scalar(value):
    if value is None:
        return ''
    if type(value) is bool:
        return str(value).lower()
    return str(value)


def derive(reference, prediction):
    valid = prediction is not None
    coherent = prediction in COHERENT if valid else None
    predicted_overall = overall(prediction) if valid else None
    reference_overall = overall(reference)
    errors = [(r == N) != (p == N) for r, p in zip(reference, prediction)] if valid else [None] * 3
    return {
        'exact_vector_correct': valid and prediction == reference,
        'coherent_prediction': coherent,
        'reference_overall': reference_overall,
        'predicted_overall': predicted_overall,
        'binary_correct': predicted_overall is not None and predicted_overall == reference_overall,
        'fp': (reference_overall == 'CONSISTENT' and predicted_overall == 'INCONSISTENT') if predicted_overall else None,
        'fn': (reference_overall == 'INCONSISTENT' and predicted_overall == 'CONSISTENT') if predicted_overall else None,
        **{'applicability_error_' + c: e for c, e in zip(CATS, errors)},
        'applicability_error_any': any(errors) if valid else None,
        'applicability_error_categories': (','.join(c for c, e in zip(CATS, errors) if e) or 'NONE') if valid else None,
        'output_valid': valid,
        'binary_decision_available': predicted_overall is not None,
        'binary_exclusion_reason': 'PARSER_FAILURE' if not valid else ('INCOHERENT_VECTOR' if not coherent else None),
        'reference_vector': code(reference),
        'predicted_vector': code(prediction) if valid else None,
    }


def sources():
    raw = {name: (ROOT / 'sources' / name).read_bytes() for name in PINNED}
    for name, expected in PINNED.items():
        require(digest(raw[name]) == expected, 'Pinned source changed: ' + name)
    raw['source_provenance.json'] = (ROOT / 'sources/source_provenance.json').read_bytes()
    for entry in json.loads(raw['source_provenance.json'])['sources']:
        b = raw[Path(entry['bundled_path']).name]
        require(digest(b) == entry['sha256'] and len(b) == entry['size_bytes'], 'Provenance mismatch')
    with zipfile.ZipFile(io.BytesIO(raw['experiment_10003_verification.zip'])) as z:
        require(len(z.namelist()) == len(set(z.namelist())) == 17, 'Unexpected ZIP membership')
        members = {n.removeprefix('verification_10003/'): z.read(n) for n in z.namelist()}
    hash_lines = members['SHA256SUMS'].decode().splitlines()
    require(len(hash_lines) == 16, 'Unexpected verification manifest count')
    for line in hash_lines:
        h, name = line.split('  ', 1)
        require(digest(members[name]) == h, 'Verification member changed: ' + name)
    return raw, members


def build_rows(raw, members):
    snapshot = json.loads(members['evidence/scoped_snapshot.json'])
    setup = json.loads(members['evidence/setup.json'])
    audit = json.loads(members['evidence/verification.json'])
    dataset = json.loads(raw['dataset.json'])
    freeze = json.loads(raw['freeze.json'])
    archive = index(snapshot['archive_files'], 'file_id')
    bindings = snapshot['bindings']
    require(bindings == setup['bindings'], 'Snapshot/setup bindings differ')
    relational = {k: snapshot[k] for k in ('experiment', 'bindings', 'runs', 'attempts', 'predictions', 'reports')}
    require(digest(encode(relational)) == audit['scoped_relational_sha256'], 'Relational snapshot hash mismatch')
    require(snapshot['experiment']['id'] == 10003 and snapshot['experiment']['dataset_id'] == setup['dataset_id'] == 3,
            'Wrong experiment/dataset')
    require(audit['status'] == 'PASS_WITH_EXPORT_CAPABILITY_BLOCKER', 'Unexpected prior verification status')
    require(digest(raw['freeze.json']) == setup['dataset_root'], 'Dataset root binding mismatch')
    for name, fid in [('dataset.json', 13272), ('freeze.json', 13277), ('p2_structured_checklist_v1.txt', 53)]:
        require(digest(raw[name]) == archive[fid]['sha256'] and len(raw[name]) == archive[fid]['size_bytes'],
                'Source not bound to snapshot: ' + name)
    require(freeze['dataset_sha256'] == digest(raw['dataset.json']), 'Freeze/dataset mismatch')
    require(digest(members['evidence/setup.json']) == archive[snapshot['experiment']['setup_file_id']]['sha256'],
            'Setup file binding mismatch')
    for f in setup['files']:
        require(archive[f['file_id']]['sha256'] == f['sha256'], 'Archived setup source identity mismatch')
    require(len(archive) == audit['verified_archive_files'] == 6238, 'Archive inventory mismatch')
    require(dataset['status'] == 'FROZEN' and dataset['name'] == 'FINAL_EVALUATION_DATASET_V2', 'Wrong frozen dataset')
    require(len(dataset['cases']) == 82, 'Wrong case count')
    require(dataset['ordered_case_ids'] == [c['candidate_id'] for c in dataset['cases']], 'Dataset order mismatch')
    require(setup['prompt_sha256'] == PINNED['p2_structured_checklist_v1.txt'], 'P2 identity mismatch')
    require(bindings['prompts'] == [{'file_id': 53, 'id': 2, 'name': 'P2', 'parent_prompt_id': None,
                                   'strategy': 'checklist', 'version': 'v1'}], 'Unexpected prompt binding')

    cases = index(bindings['dataset_cases'])
    tests = index(bindings['test_cases'])
    refs = index(bindings['reference_results'])
    models = index(bindings['models'])
    runtime_models = index(setup['models'], 'name')
    configurations = index(bindings['run_configs'])
    operations = index(bindings['api_operations'])
    contracts = index(bindings['api_contracts'])
    responses = index(bindings['responses'])
    attempts = index(snapshot['attempts'], 'run_id')
    predictions = index(snapshot['predictions'], 'run_id')
    evidence = index(snapshot['run_evidence'], 'run_id')
    schedule = index(setup['schedule'], 'run_order')
    requests = index(setup['request_inventory'], 'run_order')
    metadata = index(dataset['cases'], 'candidate_id')
    runs = sorted(snapshot['runs'], key=lambda r: r['run_order'])
    require(len(runs) == len(index(runs)) == len(attempts) == len(evidence) == len(schedule) == 738, 'Run cardinality mismatch')
    require(set(attempts) == set(evidence) == {r['id'] for r in runs}, 'Orphan evidence/attempt')
    require(set(predictions) <= set(attempts) and len(predictions) == 734, 'Unexpected predictions')
    require(len(cases) == len(tests) == len(refs) == 82, 'Case/reference join mismatch')
    require({m['name'] for m in models.values()} == MODELS, 'Model roster mismatch')
    require([r['run_order'] for r in runs] == list(range(1, 739)), 'Run order mismatch')
    family_binding = {}
    for dc in cases.values():
        tc, ref, c = tests[dc['case_id']], refs[dc['reference_id']], metadata[dc['case_code']]
        require(c['position'] == dc['position'] and c['candidate_id'] == tc['native_case_id'], 'Case order/identity mismatch')
        require(c['manual_review_status'] == 'APPROVED' and c['reference_status'] == 'HUMAN_CONFIRMED_REFERENCE', 'Unconfirmed reference')
        require(tc['source_file_id'] == ref['source_file_id'] == 13050 and ref['case_id'] == tc['id'], 'Reference source mismatch')
        require(ref['source_pointer'] == tc['source_pointer'] + '/oracle', 'Reference pointer mismatch')
        require(tc['source_pointer'] == '/cases/' + str(c['position'] - 1), 'Case pointer mismatch')
        vector = tuple(ref[k] for k in CATS)
        require(vector in COHERENT and vector == tuple(c[k.upper()] for k in CATS), 'Frozen reference changed')
        require(overall(vector) == c['overall_consistency'] == c['reviewer_decision_overall'], 'Overall reference mismatch')
        require(vector == tuple(c['reviewer_decision_' + k.upper()] for k in CATS), 'Review verdict mismatch')
        operation = operations[tc['operation_id']]
        response = responses[tc['response_id']]
        require(operation['path_template'] == c['operation_path'] and operation['http_method'] == 'post', 'Operation mismatch')
        require(archive[contracts[operation['contract_id']]['file_id']]['sha256'] == c['contract_sha256'], 'Contract mismatch')
        require(response['status_code'] == c['http_status'] and response['content_type'] == c['content_type'], 'Response metadata mismatch')
        require(archive[response['body_file_id']]['sha256'] == c['body_sha256'], 'Response body binding mismatch')
        prior = family_binding.setdefault(tc['family_id'], c['dependency_family'])
        require(prior == c['dependency_family'], 'Family binding mismatch')
    require(len(set(family_binding.values())) == len(family_binding) == 30, 'Family mapping not one-to-one')

    result = []
    for run in runs:
        rid = run['id']
        dc = cases[run['dataset_case_id']]
        tc, ref, c = tests[dc['case_id']], refs[dc['reference_id']], metadata[dc['case_code']]
        model, attempt, ev = models[run['model_id']], attempts[rid], evidence[rid]
        prediction = predictions.get(rid)
        require(run['experiment_id'] == 10003 and run['dataset_id'] == dc['dataset_id'] == 3, 'Run scope mismatch')
        require({k: run[k] for k in schedule[run['run_order']]} == schedule[run['run_order']], 'Schedule binding mismatch')
        require(run['prompt_id'] == 2 and run['run_config_id'] in configurations, 'Prompt/config mismatch')
        require(attempt['attempt'] == 1 and attempt['result'] == run['result'], 'Retry/outcome mismatch')
        require(attempt['error_kind'] is None and attempt['http_status'] == 200, 'Unexpected technical error')
        require(attempt['request_file_id'] == run['request_file_id'] == requests[run['run_order']]['file_id'], 'Request ID mismatch')
        require(ev['request_sha256'] == archive[attempt['request_file_id']]['sha256'] == requests[run['run_order']]['sha256'], 'Request hash mismatch')
        require(ev['response_sha256'] == archive[attempt['response_file_id']]['sha256'], 'Response hash mismatch')
        proof = setup['context_proofs'][str(run['run_order'])]
        require(proof['request_sha256'] == ev['request_sha256'] and proof['model_digest'] == model['digest'], 'Context proof mismatch')
        require(proof['template_sha256'] == runtime_models[model['name']]['template_sha256'], 'Template mismatch')
        reference = tuple(ref[k] for k in CATS)
        predicted = tuple(prediction[k] for k in CATS) if prediction else None
        if run['result'] == 'valid':
            require(prediction is not None and prediction['attempt_id'] == attempt['id'], 'Prediction join mismatch')
            require(all(x in (P, F, N) for x in predicted), 'Illegal stored verdict')
            require(ev['parser'] == {'code': 'ACCEPTED', 'path': '', 'status': 'VALID_OUTPUT'}, 'Parser status mismatch')
        else:
            require(run['result'] == 'parser_failure' and predicted is None and rid in FAILURES, 'Unexpected terminal failure')
            require((dc['case_code'], run['repetition'], run['seed']) == FAILURES[rid], 'Known failure identity mismatch')
            require(model['name'] == 'mistral-small3.2:24b' and attempt['done_reason'] == 'stop', 'Known failure model/termination mismatch')
            require(ev['parser'] == {'code': 'CATEGORY_FIELDS', 'path': '', 'status': 'PARSER_FAILURE'}, 'Known failure diagnostic mismatch')
            for label, file_id in [('provider', attempt['response_file_id']), ('diagnostics', attempt['diagnostics_file_id'])]:
                require(digest(members[f'evidence/run_{rid}_{label}.json']) == archive[file_id]['sha256'], 'Failure evidence hash mismatch')
        row = dict(run_id=rid, case_id=dc['case_code'], api=c['api'], family=c['dependency_family'],
                   case_characteristic=c['natural_vs_controlled'], model=model['name'],
                   repetition=run['repetition'], seed=run['seed'],
                   **{'reference_' + k: v for k, v in zip(CATS, reference)},
                   parser_status=ev['parser']['status'], parser_diagnostic=ev['parser']['code'],
                   **{'predicted_' + k: predicted[i] if predicted else None for i, k in enumerate(CATS)},
                   **derive(reference, predicted), run_result=run['result'],
                   **{k: c[k] for k in ('service_state', 'execution_origin', 'input_family', 'input_format',
                       'observed_mode', 'business_code', 'paired_original_final_candidate_id', 'paired_original_membership',
                       'input_lineage_id', 'response_pattern_group', 'exact_model_context_sha256', 'independent_scientific_ancestry')},
                   experiment_id=10003, dataset_id=3, run_order=run['run_order'], case_position=dc['position'],
                   dataset_case_id=dc['id'], case_record_id=tc['id'], reference_id=ref['id'], family_record_id=tc['family_id'],
                   model_id=model['id'], model_digest=model['digest'], model_template_sha256=proof['template_sha256'],
                   prompt_id=run['prompt_id'], run_config_id=run['run_config_id'], attempt_id=attempt['id'],
                   attempt_number=attempt['attempt'], prediction_id=prediction['id'] if prediction else None,
                   request_file_id=attempt['request_file_id'], response_file_id=attempt['response_file_id'],
                   diagnostics_file_id=attempt['diagnostics_file_id'], request_sha256=ev['request_sha256'],
                   response_sha256=ev['response_sha256'], diagnostics_sha256=archive[attempt['diagnostics_file_id']]['sha256'],
                   recovery_spool_sha256=ev['spool_sha256'], reference_source_file_id=ref['source_file_id'],
                   reference_source_pointer=ref['source_pointer'], case_metadata_pointer='/cases/' + str(dc['position'] - 1))
        require(set(row) == set(FIELDS), 'Unexpected export columns')
        result.append(row)
    return result, snapshot, setup, audit, dataset, family_binding


def validate(rows):
    require(len(rows) == 738 and len({r['run_id'] for r in rows}) == 738, 'Not 738 distinct logical rows')
    cases = {r['case_id']: r for r in rows}
    expected = {(c, m, rep, seed) for c in cases for m in MODELS for rep, seed in ((1, 101), (2, 202), (3, 303))}
    actual = {(r['case_id'], r['model'], r['repetition'], r['seed']) for r in rows}
    require(len(cases) == 82 and len(actual) == 738 and actual == expected, 'Missing/duplicated factorial slot')
    counts = Counter(r['run_result'] for r in rows)
    require(counts == {'valid': 734, 'parser_failure': 4}, 'Unexpected final outcomes')
    reference_counts = Counter(r['reference_vector'] for r in cases.values())
    api_counts = Counter(r['api'] for r in cases.values())
    require(reference_counts == {'PPP': 29, 'PPF': 10, 'PFN': 29, 'FNN': 14}, 'Reference distribution mismatch')
    require(api_counts == {'EDX': 52, 'Resistance': 30}, 'API distribution mismatch')
    failed = [r for r in rows if not r['output_valid']]
    require({r['run_id'] for r in failed} == set(FAILURES), 'Known failure set mismatch')
    for r in failed:
        require(all(r[k] is None for k in ('predicted_c1', 'predicted_c2', 'predicted_c3', 'predicted_vector',
            'predicted_overall', 'coherent_prediction', 'fp', 'fn', 'applicability_error_c1',
            'applicability_error_c2', 'applicability_error_c3', 'applicability_error_any', 'applicability_error_categories')),
            'Failure has imputed semantic data')
        require(r['exact_vector_correct'] is False and r['binary_correct'] is False, 'Failure-aware flag mismatch')
    return dict(status='PASS', rows=738, distinct_runs=738, cases=82, models=3, repetitions=3,
                seeds=[101, 202, 303], complete_factorial_design=True, physical_attempts=738, retries=0,
                outcomes={'valid': 734, 'parser_failure': 4, 'technical_failure': 0},
                reference_distribution_cases=dict(sorted(reference_counts.items())),
                api_distribution_cases=dict(sorted(api_counts.items())),
                known_parser_failures=[{k: r[k] for k in ('run_id', 'case_id', 'model', 'repetition', 'seed',
                    'parser_status', 'parser_diagnostic')} for r in failed],
                missing_predictions_preserved=True, original_bindings_verified=True)


def dictionary():
    descriptions = {
        'family': 'Exact dataset dependency_family. Grouping metadata, not proof of independent scientific ancestry.',
        'case_characteristic': 'Exact dataset natural_vs_controlled label; service_state and other original characteristics are separate columns.',
        'parser_status': 'Stored run_evidence.parser.status: VALID_OUTPUT or PARSER_FAILURE; parser is not rerun.',
        'parser_diagnostic': 'Stored run_evidence.parser.code: ACCEPTED or CATEGORY_FIELDS.',
        'exact_vector_correct': 'True iff a stored valid prediction equals all three frozen reference states. False for terminal failures.',
        'coherent_prediction': 'Valid prediction belongs to PPP, PPF, PFN or FNN. Null when no prediction exists.',
        'reference_overall': 'CONSISTENT for reference PPP, INCONSISTENT for reference PPF/PFN/FNN.',
        'predicted_overall': 'CONSISTENT for predicted PPP, INCONSISTENT for PPF/PFN/FNN. Null for incoherent or absent predictions.',
        'binary_correct': 'True iff a usable derived overall prediction equals reference_overall. False for absent/incoherent predictions. Failure-aware flag, not semantic confusion membership.',
        'fp': 'On available overall decisions only: reference CONSISTENT and prediction INCONSISTENT. Null when binary decision unavailable.',
        'fn': 'On available overall decisions only: reference INCONSISTENT and prediction CONSISTENT. Null when binary decision unavailable.',
        'applicability_error_any': 'Any per-category reference/prediction NOT_APPLICABLE mismatch; null for missing prediction.',
        'applicability_error_categories': 'c1,c2,c3 in fixed order for mismatches; NONE for no mismatch; null for missing prediction.',
        'output_valid': 'True for run_result=valid with its original stored prediction; includes incoherent valid vectors.',
        'binary_decision_available': 'True iff predicted_overall is non-null.',
        'binary_exclusion_reason': 'PARSER_FAILURE, INCOHERENT_VECTOR or null when binary decision is available.',
        'reference_vector': 'Frozen vector as three characters P=PASS, F=FAIL, N=NOT_APPLICABLE.',
        'predicted_vector': 'Original stored vector as three P/F/N characters; null for parser failure.',
        'case_id': 'Dataset case_code, matched to dataset.json candidate_id and test_cases.native_case_id.',
        'case_record_id': 'Numeric test_cases.id; distinct from case_id text identifier.',
        'case_metadata_pointer': 'JSON Pointer into bundled sources/dataset.json.',
        'reference_source_pointer': 'Original JSON Pointer into archived main-v2-sql-projection.json (file 13050).',
    }
    for c in CATS:
        descriptions['applicability_error_' + c] = 'True iff exactly one of reference_' + c + ' and predicted_' + c + ' is NOT_APPLICABLE. Null for missing prediction; applies also to incoherent valid outputs.'
        descriptions['reference_' + c] = 'Frozen reference_results.' + c + ', cross-checked against human-confirmed dataset.json reference.'
        descriptions['predicted_' + c] = 'Original predictions.' + c + '; null for parser failures. No label repair or imputation.'
    return dict(format='experiment-10003-column-dictionary-v1',
                csv=dict(encoding='UTF-8 without BOM', delimiter=',', quotechar='"', line_ending='LF',
                         header_rows=1, data_rows=738, null_encoding='empty field', boolean_encoding=['true', 'false'],
                         sort_order='ascending original run_order'),
                definitions_status='Deterministic offline derivation rules documented for this requested export; not a new or modified experiment setup or pre-run Main-v2 metric freeze.',
                positive_class='INCONSISTENT', coherent_vectors=['PPP', 'PPF', 'PFN', 'FNN'],
                coherence_basis='Hash-bound original P2 ordered C1/C2/C3 applicability policy.',
                applicability_basis='Reference-versus-prediction applicability mismatch, separately from internal vector coherence.',
                missing_policy='Empty means unavailable/source null, never verdict NOT_APPLICABLE. Boolean false is explicit. Parser failures have no semantic prediction, confusion flag or applicability error. They remain rows with failure-aware correctness false.',
                grouping_basis='Use stored dependency_family and pair links exactly. independent_scientific_ancestry remains UNESTABLISHED. No independent-family inference or new grouping.',
                no_aggregation='One logical run per row. No majority vote, best seed, performance metric, confidence interval or interpretation is produced.',
                columns=[dict(name=f, type='boolean' if f in BOOLS else ('integer' if f in INTS else 'string'),
                              description=descriptions.get(f, 'Unchanged source metadata/binding; see source_field_map.')) for f in FIELDS],
                source_field_map={
                    'snapshot': 'sources/experiment_10003_verification.zip!verification_10003/evidence/scoped_snapshot.json',
                    'required_identity': 'runs.id -> runs.dataset_case_id -> bindings.dataset_cases.id; case_code -> dataset.json candidate_id; model_id -> bindings.models.id',
                    'reference': 'dataset_cases.reference_id -> bindings.reference_results.id; cross-check dataset.json C1/C2/C3 and reviewer_decision_C1/C2/C3',
                    'prediction': 'runs.id -> predictions.run_id, validated against attempts.id; missing for parser_failure',
                    'parser': 'runs.id -> run_evidence.run_id -> parser.status/code',
                    'api_family_characteristic': 'dataset.json cases[*].api/dependency_family/natural_vs_controlled; family_record_id is snapshot test_cases.family_id',
                    'dataset_metadata': 'service_state, execution_origin, input_family, input_format, observed_mode, business_code, paired_original_final_candidate_id, paired_original_membership, input_lineage_id, response_pattern_group, exact_model_context_sha256 and independent_scientific_ancestry copied by identical field name',
                    'model_template_sha256': 'setup.json context_proofs[run_order].template_sha256; matched to setup.models',
                    'artifact_hashes': 'snapshot run_evidence and archive_files, joined by file_id',
                })


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True, help='New empty output directory, outside all source directories')
    args = ap.parse_args()
    output = args.output.resolve()
    require(not output.exists(), 'Refusing to overwrite existing output directory')
    started = datetime.now(timezone.utc)
    raw, members = sources()
    before = {n: digest(b) for n, b in raw.items()}
    rows, snapshot, setup, audit, dataset, family_binding = build_rows(raw, members)
    integrity = validate(rows)
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=FIELDS, lineterminator='\n')
    writer.writeheader()
    writer.writerows({k: scalar(v) for k, v in r.items()} for r in rows)
    csv_raw = stream.getvalue().encode('utf-8')
    parsed = list(csv.DictReader(io.StringIO(csv_raw.decode('utf-8'), newline='')))
    require(parsed == [{k: scalar(v) for k, v in row.items()} for row in rows], 'CSV roundtrip mismatch')
    require(len(csv_raw.splitlines()) == 739, 'Unexpected multiline CSV record')
    # Re-read all input files before publishing; no source byte was changed by this script.
    require(before == {n: digest((ROOT / 'sources' / n).read_bytes()) for n in raw}, 'Source drift during export')
    integrity.update(source_copies_unchanged=True, csv_roundtrip_verified=True, physical_csv_lines=739,
                     verification_zip_members_hash_checked=16, source_inventory_entries=6238,
                     current_full_archive_payload_rehash=False,
                     archive_payload_note='Original audit verified all 6238 payloads. This export verifies the immutable snapshot/inventory and bundled inputs; it does not reopen the database archive.',
                     database_connections=0, database_writes=0, model_calls=0, retries_created=0,
                     parser_reruns=0, production_imports=0)
    payload = {'analysis_10003.csv': csv_raw, 'column_dictionary.json': pretty(dictionary()),
               'integrity.json': pretty(integrity), 'build_export.py': Path(__file__).read_bytes(),
               **{'sources/' + n: b for n, b in raw.items()}}
    payload['README.txt'] = (
        'Experiment 10003: frozen offline analysis table for RQ1-RQ3\n\n'
        '738 data records plus one header. The only observations/predictions are the original saved snapshot.\n'
        'Source ZIP is preserved byte-for-byte. Dataset/freeze/P2 source copies match its archived identities.\n'
        'Read column_dictionary.json before aggregating. Empty fields are unavailable, not NOT_APPLICABLE.\n'
        'case_characteristic copies natural_vs_controlled; family copies dependency_family without reinterpretation.\n'
        'No overall label or semantic FP/FN is assigned to a parser failure or incoherent vector.\n'
        'Failures have exact_vector_correct=false and binary_correct=false for failure-aware counting.\n'
        'coherent_prediction and applicability errors are null for absent predictions.\n'
        'The four CATEGORY_FIELDS failures are final, unrepaired records.\n\n'
        'Reproduce using Python 3.9+ standard library, no repository/environment/credentials/services needed:\n'
        '  python3 build_export.py --output /absolute/path/to/NEW_DIRECTORY\n'
        'Run the script from this package; output must not exist. Original inputs are never overwritten.\n'
        'The new analysis_10003.csv must have the same SHA-256 as manifest.json export.sha256.\n'
        'Manifest generation timestamps/runtime details change on reproduction; CSV bytes do not.\n'
        'SHA256SUMS covers every package file except itself. manifest.json covers all files except itself and SHA256SUMS.\n'
        'This is an offline analysis dataset, not a stored DB evaluation report or a performance interpretation.\n'
    ).encode()
    ended = datetime.now(timezone.utc)
    manifest = dict(format='experiment-10003-offline-analysis-manifest-v1',
                    generated_at_utc=ended.isoformat(), generated_at_europe_berlin=ended.astimezone(ZoneInfo('Europe/Berlin')).isoformat(),
                    started_at_utc=started.isoformat(), experiment_id=10003, dataset_id=3,
                    source_snapshot=dict(sha256=digest(members['evidence/scoped_snapshot.json']),
                                         size_bytes=len(members['evidence/scoped_snapshot.json']),
                                         zip_member='verification_10003/evidence/scoped_snapshot.json',
                                         relational_sha256=audit['scoped_relational_sha256']),
                    verified_source_members=[dict(path=n, sha256=digest(b), size_bytes=len(b)) for n, b in sorted(members.items())],
                    setup_sha256=digest(members['evidence/setup.json']), dataset_root_sha256=setup['dataset_root'],
                    dataset_sha256=digest(raw['dataset.json']), prompt_sha256=setup['prompt_sha256'],
                    original_parser_sha256=setup['parser_sha256'], model_bindings=setup['bindings']['models'],
                    run_config_bindings=setup['bindings']['run_configs'], output_interface=setup['output_interface'],
                    family_id_mapping=[dict(family_record_id=k, family=v) for k, v in sorted(family_binding.items())],
                    original_frozen_denominators=dataset['denominators'],
                    runtime=dict(python=sys.version, dependencies='Python standard library only'),
                    script=dict(path='build_export.py', sha256=digest(payload['build_export.py'])),
                    export=dict(path='analysis_10003.csv', sha256=digest(csv_raw), size_bytes=len(csv_raw), rows=738, columns=len(FIELDS)),
                    integrity=integrity,
                    files=[dict(path=n, sha256=digest(b), size_bytes=len(b)) for n, b in sorted(payload.items())])
    payload['manifest.json'] = pretty(manifest)
    payload['SHA256SUMS'] = ''.join(f'{digest(b)}  {n}\n' for n, b in sorted(payload.items())).encode()
    output.mkdir(parents=True, exist_ok=False)
    for name, body in payload.items():
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as f:
            f.write(body)
    for name, body in payload.items():
        require((output / name).read_bytes() == body, 'Saved output differs: ' + name)
    print(json.dumps({'status': 'PASS', 'output': str(output), 'rows': 738,
                      'csv_sha256': digest(csv_raw), 'script_sha256': digest(payload['build_export.py']),
                      'manifest_sha256': digest(payload['manifest.json'])}, sort_keys=True))


if __name__ == '__main__':
    main()
